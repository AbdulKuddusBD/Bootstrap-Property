import csv, re, unicodedata, subprocess, cv2, numpy as np, sqlite3, sys
from pathlib import Path
from PIL import Image
CSV='/mnt/data/2393.csv'
DB='/mnt/data/2393.db'
REPORT='/mnt/data/2393_review_report.csv'
RENDER_DIR=Path('/mnt/data/ocr_pages_2393_200')
headers=['ক্রমিক নং','ভোটার নং','নাম','পিতা','মাতা','পেশা','জন্ম তারিখ','ঠিকানা']

def bn_int(s):
    out=''
    for ch in str(s):
        try: out+=str(unicodedata.digit(ch))
        except: pass
    return int(out) if out else None

def clean(s):
    if not s: return ''
    s=s.replace('_',' ').replace('—','-').replace('।','').replace('নং.','নং:').replace('নং ', 'নং: ')
    s=s.replace('মৌঃ','মোঃ').replace('মেঃ','মোঃ').replace('মােঃ','মোঃ')
    s=s.replace('হোসেন','হোসেন').replace('হোসাইন','হোসাইন').replace('বেসরকারী চাকুরী ,','বেসরকারী চাকুরী,')
    s=re.sub(r'\s+',' ',s).strip(' ,-:')
    return s

def parse_crop_text(text):
    txt='\n'.join(clean(l) for l in text.splitlines() if clean(l))
    d={}
    m=re.search(r'([০-৯0-9]{4})\.\s*নাম\s*[:：]\s*([^\n]+)',txt)
    if m: d['ক্রমিক নং']=m.group(1); d['নাম']=clean(m.group(2))
    m=re.search(r'ভোটার নং\s*[:：.]?\s*([۰۱۲۳۴۵۶۷۸۹۰۱۲۳۴۵۶۷۸۹0-9]{8,})',txt)
    if m: d['ভোটার নং']=clean(m.group(1))
    for lab,key in [('পিতা','পিতা'),('মাতা','মাতা')]:
        m=re.search(lab+r'\s*[:：]\s*([^\n]+)',txt)
        if m: d[key]=clean(m.group(1))
    m=re.search(r'পেশা\s*[:：]\s*(.*?)(?:,|-| )\s*জন্ম\s*তারিখ\s*[:：]?\s*([۰۱۲۳۴۵۶۷۸۹۰۱۲۳۴۵۶۷۸۹0-9/\-]+)',txt)
    if m: d['পেশা']=clean(m.group(1)); d['জন্ম তারিখ']=clean(m.group(2))
    m=re.search(r'ঠিকানা\s*[:：]\s*([^\n]+)',txt)
    if m: d['ঠিকানা']=clean(m.group(1))
    return d, txt

def suspicious(v):
    if not v: return True
    for ch in v:
        if ch in ' .,-/:()।': continue
        try: unicodedata.digit(ch); continue
        except Exception: pass
        if not ('\u0980' <= ch <= '\u09ff'):
            return True
    return False

def detect_cells(img_path):
    img=cv2.imread(str(img_path),0)
    _,th=cv2.threshold(img,180,255,cv2.THRESH_BINARY_INV)
    h_kernel=cv2.getStructuringElement(cv2.MORPH_RECT,(55,1))
    h=cv2.morphologyEx(th,cv2.MORPH_OPEN,h_kernel)
    contours,_=cv2.findContours(h, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    lines=[]
    for c in contours:
        x,y,w,hgt=cv2.boundingRect(c)
        if 500<w<800 and hgt<=8 and y>50:
            lines.append((x,y,w,hgt))
    # group by row y and x
    ys=sorted(set(y for x,y,w,hgt in lines))
    # use pairs of horizontal lines for box top/bottom: each row has top and bottom, double boundary gaps.
    # collect x groups from first row
    xs=sorted(set(x for x,y,w,hgt in lines))
    # cluster close x
    def cluster(vals,gap=20):
        groups=[]
        for v in vals:
            if not groups or v-groups[-1][-1]>gap: groups.append([v])
            else: groups[-1].append(v)
        return [int(round(sum(g)/len(g))) for g in groups]
    xstarts=cluster(xs)
    if len(xstarts)<3: xstarts=[188,846,1503]
    # widths approx from lines: use median w
    widths=[w for x,y,w,hgt in lines]
    width=int(np.median(widths)) if widths else 650
    # For y, identify top/bottom pairs by sorting unique line y; rows begin at y[0], then paired boundaries.
    # Filter out page header long lines by width condition, so first should be first box top.
    ys=cluster(ys, gap=8)  # merge line thickness only
    # Convert double boundary pairs to intervals: [0,1], [2,3], ... ignoring if y list has top,bottom,top,bottom...
    # In this PDF list pages have 10 y lines for 5 rows.
    if len(ys)>=10:
        yints=[]
        for i in range(0,min(10,len(ys)-1),2):
            yints.append((ys[i],ys[i+1]))
    else:
        # fallback by page type
        page=int(re.search(r'p-(\d+)\.png',str(img_path)).group(1))
        if page==3:
            yints=[(317,531),(542,756),(767,981),(992,1206),(1217,1431)]
        else:
            yints=[(89,303),(314,528),(539,753),(764,978),(989,1203)]
    xints=[(x,x+width) for x in xstarts[:3]]
    return xints,yints

# load rows
with open(CSV,encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
byserial={bn_int(r['ক্রমিক নং']): r for r in rows}
# target serials: suspicious fields + common likely OCR shortening
targets=set()
for s,r in byserial.items():
    if any(suspicious(r[h]) for h in headers): targets.add(s)
    if r['পিতা'].startswith('মাতা '): targets.add(s)
    if 'জুয়লে' in r['নাম'] or 'এনায়তে' in r['ঠিকানা']: targets.add(s)
# also first page sanity targets
#targets.update(range(1,16))
print('targets',len(targets), file=sys.stderr)
cell_cache={}
for idx,s in enumerate(sorted(targets),1):
    page=3+(s-1)//15
    pos=(s-1)%15
    row=pos//3; col=pos%3
    img_path=RENDER_DIR/f'p-{page:02d}.png'
    if not img_path.exists(): continue
    if page not in cell_cache: cell_cache[page]=detect_cells(img_path)
    xints,yints=cell_cache[page]
    if row>=len(yints) or col>=len(xints): continue
    x1,x2=xints[col]; y1,y2=yints[row]
    img=Image.open(img_path)
    crop=img.crop((x1+5,y1+5,x2-5,y2-5))
    tmp=f'/tmp/cell_{s}.png'; crop.save(tmp)
    try:
        out=subprocess.run(['tesseract',tmp,'stdout','-l','ben','--psm','4'],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,timeout=8)
        text=out.stdout.decode('utf-8','replace')
    except Exception:
        continue
    vals,txt=parse_crop_text(text)
    r=byserial[s]
    for h,v in vals.items():
        if h=='ক্রমিক নং': continue
        if not v: continue
        # override if current suspicious/missing, or crop value is at least as long and not suspicious.
        cur=r.get(h,'')
        if suspicious(cur) or len(v)>=len(cur)-1 or h in ['নাম','ভোটার নং','পেশা','জন্ম তারিখ','ঠিকানা']:
            r[h]=v
    if idx%25==0: print('patched',idx,'/',len(targets), file=sys.stderr)

# final quick replacements
for r in rows:
    for h in headers:
        v=r[h]
        for a,b in {'Ĩ':'ন্ন','শ্রিমক':'শ্রমিক','জুয়লে':'জুয়েল','এনায়তে':'এনায়েত','হোসেন':'হোসেন','মাতা উদ্দিন':'মাতাব উদ্দিন'}.items(): v=v.replace(a,b)
        r[h]=clean(v)
# rewrite
with open(CSV,'w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=headers); w.writeheader(); w.writerows(rows)
# db rewrite
p=Path(DB); 
if p.exists(): p.unlink()
conn=sqlite3.connect(DB); conn.execute('CREATE TABLE voters ('+', '.join([f'"{h}" TEXT' for h in headers])+')')
conn.executemany('INSERT INTO voters VALUES ('+','.join(['?']*len(headers))+')', [[r[h] for h in headers] for r in rows])
for h in ['ভোটার নং','নাম','পিতা','মাতা']:
    conn.execute(f'CREATE INDEX idx_{headers.index(h)} ON voters("{h}")')
conn.commit(); conn.close()
# report
bad=[]
for r in rows:
    for h in headers:
        if suspicious(r[h]): bad.append({'ক্রমিক নং':r['ক্রমিক নং'],'field':h,'value':r[h]})
with open(REPORT,'w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=['ক্রমিক নং','field','value']); w.writeheader(); w.writerows(bad)
print('bad_fields',len(bad))
