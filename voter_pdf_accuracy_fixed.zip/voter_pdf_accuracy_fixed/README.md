# Voter PDF Database Site - Accuracy Fixed

এই ভার্সনে export columns ঠিক করা হয়েছে:

1. ক্রমিক নং
2. ভোটার নং
3. নাম
4. পিতা
5. মাতা
6. পেশা
7. জন্ম তারিখ
8. ঠিকানা

## Main fixes

- CSV/DB export filename ভোটার এলাকার নম্বর থেকে হয়, যেমন `2393.csv`, `2393.db`।
- Web export আর extra columns দেয় না।
- `accuracy_export.py` OCR-hybrid mode যোগ করা হয়েছে, কারণ Election Commission PDF-এর embedded Bangla font অনেক সময় ভুল Unicode দেয়।
- `patch_suspicious_crops.py` suspicious rows crop OCR দিয়ে আবার পড়ে।
- `review_report.csv` তৈরি হয়, যাতে কোনো সন্দেহজনক field থাকলে আগে review করা যায়।

## Run web app

```bash
pip install -r requirements.txt
python app.py
```

## Accuracy export command

```bash
python accuracy_export.py
python patch_suspicious_crops.py
```

Production ব্যবহারে export করার আগে review report খালি আছে কি না চেক করবেন।
