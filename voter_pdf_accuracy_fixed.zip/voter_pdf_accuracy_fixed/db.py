import sqlite3
from pathlib import Path
from typing import Iterable, Dict, Any, Optional

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "instance" / "voter_data.db"


def get_conn(db_path: Optional[Path] = None):
    path = db_path or DB_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db():
    with get_conn() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS imported_files (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                filename TEXT NOT NULL,
                saved_path TEXT NOT NULL,
                sha256 TEXT NOT NULL UNIQUE,
                status TEXT NOT NULL DEFAULT 'imported',
                error TEXT,
                total_records INTEGER NOT NULL DEFAULT 0,
                district TEXT,
                upazila TEXT,
                union_name TEXT,
                ward_no TEXT,
                voter_area TEXT,
                voter_area_no TEXT,
                list_gender TEXT,
                published_date TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS voters (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                file_id INTEGER NOT NULL,
                source_file TEXT NOT NULL,
                pdf_page INTEGER,
                list_page INTEGER,
                serial_text TEXT,
                serial_no INTEGER,
                voter_no TEXT,
                voter_no_ascii TEXT,
                name TEXT,
                father TEXT,
                mother TEXT,
                occupation TEXT,
                birth_date TEXT,
                address TEXT,
                district TEXT,
                upazila TEXT,
                union_name TEXT,
                ward_no TEXT,
                voter_area TEXT,
                voter_area_no TEXT,
                list_gender TEXT,
                published_date TEXT,
                raw_record TEXT,
                search_blob TEXT,
                confidence INTEGER NOT NULL DEFAULT 0,
                needs_review INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT,
                FOREIGN KEY(file_id) REFERENCES imported_files(id) ON DELETE CASCADE
            );

            CREATE UNIQUE INDEX IF NOT EXISTS idx_voters_file_serial ON voters(file_id, serial_no);
            CREATE INDEX IF NOT EXISTS idx_voters_voter_no ON voters(voter_no_ascii);
            CREATE INDEX IF NOT EXISTS idx_voters_name ON voters(name);
            CREATE INDEX IF NOT EXISTS idx_voters_father ON voters(father);
            CREATE INDEX IF NOT EXISTS idx_voters_mother ON voters(mother);
            CREATE INDEX IF NOT EXISTS idx_voters_area ON voters(voter_area_no, voter_area);
            CREATE INDEX IF NOT EXISTS idx_voters_search ON voters(search_blob);
            """
        )


def insert_imported_file(meta: Dict[str, Any]) -> int:
    keys = [
        "filename", "saved_path", "sha256", "status", "error", "total_records",
        "district", "upazila", "union_name", "ward_no", "voter_area",
        "voter_area_no", "list_gender", "published_date"
    ]
    data = {k: meta.get(k) for k in keys}
    with get_conn() as conn:
        cur = conn.execute(
            f"INSERT INTO imported_files ({', '.join(keys)}) VALUES ({', '.join(['?'] * len(keys))})",
            [data[k] for k in keys],
        )
        return int(cur.lastrowid)


def update_imported_file(file_id: int, **kwargs):
    if not kwargs:
        return
    cols = ", ".join([f"{k}=?" for k in kwargs.keys()])
    vals = list(kwargs.values()) + [file_id]
    with get_conn() as conn:
        conn.execute(f"UPDATE imported_files SET {cols} WHERE id=?", vals)


def insert_voters(records: Iterable[Dict[str, Any]]):
    records = list(records)
    if not records:
        return 0
    keys = [
        "file_id", "source_file", "pdf_page", "list_page", "serial_text", "serial_no",
        "voter_no", "voter_no_ascii", "name", "father", "mother", "occupation",
        "birth_date", "address", "district", "upazila", "union_name", "ward_no",
        "voter_area", "voter_area_no", "list_gender", "published_date", "raw_record",
        "search_blob", "confidence", "needs_review"
    ]
    rows = [[r.get(k) for k in keys] for r in records]
    with get_conn() as conn:
        conn.executemany(
            f"INSERT OR REPLACE INTO voters ({', '.join(keys)}) VALUES ({', '.join(['?'] * len(keys))})",
            rows,
        )
    return len(records)


def search_voters(q: str = "", name: str = "", father: str = "", mother: str = "", voter_no: str = "", limit: int = 100):
    from extractor import normalize_search, bangla_to_ascii_digits
    clauses = []
    params = []
    if q:
        clauses.append("search_blob LIKE ?")
        params.append(f"%{normalize_search(q)}%")
    if name:
        clauses.append("search_blob LIKE ?")
        params.append(f"%{normalize_search(name)}%")
    if father:
        clauses.append("search_blob LIKE ?")
        params.append(f"%{normalize_search(father)}%")
    if mother:
        clauses.append("search_blob LIKE ?")
        params.append(f"%{normalize_search(mother)}%")
    if voter_no:
        clauses.append("voter_no_ascii LIKE ?")
        params.append(f"%{bangla_to_ascii_digits(voter_no)}%")
    where = "WHERE " + " AND ".join(clauses) if clauses else ""
    with get_conn() as conn:
        return conn.execute(
            f"""
            SELECT voters.*, imported_files.filename AS imported_filename
            FROM voters
            LEFT JOIN imported_files ON voters.file_id = imported_files.id
            {where}
            ORDER BY voters.source_file, voters.serial_no
            LIMIT ?
            """,
            params + [limit],
        ).fetchall()


def get_stats():
    with get_conn() as conn:
        total_files = conn.execute("SELECT COUNT(*) FROM imported_files").fetchone()[0]
        total_voters = conn.execute("SELECT COUNT(*) FROM voters").fetchone()[0]
        review = conn.execute("SELECT COUNT(*) FROM voters WHERE needs_review=1").fetchone()[0]
        last_files = conn.execute("SELECT * FROM imported_files ORDER BY id DESC LIMIT 10").fetchall()
    return {"total_files": total_files, "total_voters": total_voters, "review": review, "last_files": last_files}
