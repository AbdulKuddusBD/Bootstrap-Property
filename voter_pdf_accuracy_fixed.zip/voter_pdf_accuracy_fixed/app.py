import csv
import io
import os
import shutil
from pathlib import Path
from typing import List

from flask import Flask, Response, flash, redirect, render_template, request, send_file, url_for
from werkzeug.utils import secure_filename

import db
from extractor import extract_pdf, extract_pdfs_from_zip, records_to_db_rows, sha256_file, bangla_to_ascii_digits

BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "uploads"
EXPORT_DIR = BASE_DIR / "exports"
ALLOWED = {".pdf", ".zip"}

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-this-secret-key")
app.config["MAX_CONTENT_LENGTH"] = int(os.environ.get("MAX_UPLOAD_MB", "512")) * 1024 * 1024


def allowed_file(filename: str) -> bool:
    return Path(filename).suffix.lower() in ALLOWED


@app.before_request
def _init():
    db.init_db()
    UPLOAD_DIR.mkdir(exist_ok=True)
    EXPORT_DIR.mkdir(exist_ok=True)


@app.route("/")
def index():
    return render_template("index.html", stats=db.get_stats())


@app.route("/upload", methods=["GET", "POST"])
def upload():
    if request.method == "GET":
        return render_template("upload.html")
    files = request.files.getlist("files")
    if not files or all(not f.filename for f in files):
        flash("ফাইল সিলেক্ট করা হয়নি।", "error")
        return redirect(url_for("upload"))

    saved: List[Path] = []
    for f in files:
        if not f.filename or not allowed_file(f.filename):
            continue
        filename = secure_filename(f.filename)
        if not filename:
            filename = "upload.pdf"
        target = UPLOAD_DIR / filename
        stem, suffix = target.stem, target.suffix
        counter = 1
        while target.exists():
            target = UPLOAD_DIR / f"{stem}_{counter}{suffix}"
            counter += 1
        f.save(target)
        if target.suffix.lower() == ".zip":
            saved.extend(extract_pdfs_from_zip(target, UPLOAD_DIR))
        else:
            saved.append(target)

    results = []
    for path in saved:
        file_hash = sha256_file(path)
        meta = {
            "filename": path.name,
            "saved_path": str(path),
            "sha256": file_hash,
            "status": "processing",
            "error": None,
            "total_records": 0,
        }
        try:
            file_id = db.insert_imported_file(meta)
        except Exception:
            # Duplicate hash. Do not re-import.
            results.append({"filename": path.name, "status": "duplicate", "records": 0, "error": "এই ফাইলটি আগে import করা আছে।"})
            continue
        try:
            pdf_meta, records = extract_pdf(path)
            rows = records_to_db_rows(records, file_id, path.name, pdf_meta)
            inserted = db.insert_voters(rows)
            db.update_imported_file(file_id, status="imported", total_records=inserted, **pdf_meta)
            results.append({"filename": path.name, "status": "imported", "records": inserted, "error": None})
        except Exception as e:
            db.update_imported_file(file_id, status="failed", error=str(e))
            results.append({"filename": path.name, "status": "failed", "records": 0, "error": str(e)})
    return render_template("upload_result.html", results=results)


@app.route("/search")
def search():
    q = request.args.get("q", "").strip()
    name = request.args.get("name", "").strip()
    father = request.args.get("father", "").strip()
    mother = request.args.get("mother", "").strip()
    voter_no = request.args.get("voter_no", "").strip()
    limit = min(int(request.args.get("limit", "100") or 100), 1000)
    rows = []
    if any([q, name, father, mother, voter_no]):
        rows = db.search_voters(q=q, name=name, father=father, mother=mother, voter_no=voter_no, limit=limit)
    return render_template("search.html", rows=rows, params=request.args)


@app.route("/review")
def review():
    with db.get_conn() as conn:
        rows = conn.execute(
            """
            SELECT voters.*, imported_files.filename AS imported_filename
            FROM voters
            JOIN imported_files ON imported_files.id=voters.file_id
            WHERE needs_review=1
            ORDER BY confidence ASC, voters.id DESC
            LIMIT 300
            """
        ).fetchall()
    return render_template("review.html", rows=rows)


@app.route("/record/<int:record_id>", methods=["GET", "POST"])
def edit_record(record_id: int):
    with db.get_conn() as conn:
        if request.method == "POST":
            fields = ["name", "father", "mother", "voter_no", "occupation", "birth_date", "address"]
            values = {f: request.form.get(f, "").strip() for f in fields}
            values["voter_no_ascii"] = bangla_to_ascii_digits(values["voter_no"])
            values["needs_review"] = 0 if request.form.get("mark_ok") else 1
            conn.execute(
                """
                UPDATE voters
                SET name=:name, father=:father, mother=:mother, voter_no=:voter_no,
                    voter_no_ascii=:voter_no_ascii, occupation=:occupation, birth_date=:birth_date,
                    address=:address, needs_review=:needs_review, updated_at=CURRENT_TIMESTAMP
                WHERE id=:id
                """,
                {**values, "id": record_id},
            )
            flash("রেকর্ড আপডেট হয়েছে।", "success")
            return redirect(url_for("edit_record", record_id=record_id))
        row = conn.execute("SELECT * FROM voters WHERE id=?", [record_id]).fetchone()
    if not row:
        flash("রেকর্ড পাওয়া যায়নি।", "error")
        return redirect(url_for("search"))
    return render_template("edit_record.html", row=row)


def _safe_area_filename(area_no: str, ext: str) -> str:
    from extractor import bangla_to_ascii_digits
    area = bangla_to_ascii_digits(area_no or "unknown")
    area = "".join(ch for ch in area if ch.isdigit()) or "unknown"
    return f"{area}.{ext}"


EXPORT_HEADERS = [
    ("ক্রমিক নং", "serial_text"),
    ("ভোটার নং", "voter_no"),
    ("নাম", "name"),
    ("পিতা", "father"),
    ("মাতা", "mother"),
    ("পেশা", "occupation"),
    ("জন্ম তারিখ", "birth_date"),
    ("ঠিকানা", "address"),
]


@app.route("/export/csv")
def export_csv():
    area = request.args.get("area", "").strip()
    with db.get_conn() as conn:
        if area:
            rows = conn.execute("SELECT * FROM voters WHERE voter_area_no=? ORDER BY serial_no", [area]).fetchall()
            area_no = area
        else:
            rows = conn.execute("SELECT * FROM voters ORDER BY voter_area_no, serial_no").fetchall()
            area_vals = sorted({r["voter_area_no"] for r in rows if r["voter_area_no"]})
            area_no = area_vals[0] if len(area_vals) == 1 else "all_areas"
    output = io.StringIO()
    output.write("\ufeff")
    writer = csv.DictWriter(output, fieldnames=[h for h, _ in EXPORT_HEADERS])
    writer.writeheader()
    for r in rows:
        writer.writerow({h: r[k] for h, k in EXPORT_HEADERS})
    data = output.getvalue().encode("utf-8")
    filename = _safe_area_filename(area_no, "csv") if area_no != "all_areas" else "all_areas.csv"
    return Response(data, mimetype="text/csv; charset=utf-8", headers={"Content-Disposition": f"attachment; filename={filename}"})


@app.route("/export/db")
def export_db():
    import sqlite3
    area = request.args.get("area", "").strip()
    export_path = EXPORT_DIR / (_safe_area_filename(area, "db") if area else "all_areas.db")
    if export_path.exists():
        export_path.unlink()
    out = sqlite3.connect(export_path)
    quoted_cols = ", ".join([f'"{h}" TEXT' for h, _ in EXPORT_HEADERS])
    out.execute(f"CREATE TABLE voters ({quoted_cols})")
    with db.get_conn() as conn:
        if area:
            rows = conn.execute("SELECT * FROM voters WHERE voter_area_no=? ORDER BY serial_no", [area]).fetchall()
        else:
            rows = conn.execute("SELECT * FROM voters ORDER BY voter_area_no, serial_no").fetchall()
        out.executemany(
            "INSERT INTO voters VALUES (" + ",".join(["?"] * len(EXPORT_HEADERS)) + ")",
            [[r[k] for _, k in EXPORT_HEADERS] for r in rows],
        )
    out.commit(); out.close()
    return send_file(export_path, as_attachment=True, download_name=export_path.name)


@app.route("/files")
def files():
    with db.get_conn() as conn:
        rows = conn.execute("SELECT * FROM imported_files ORDER BY id DESC").fetchall()
    return render_template("files.html", rows=rows)


if __name__ == "__main__":
    db.init_db()
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")), debug=True)
