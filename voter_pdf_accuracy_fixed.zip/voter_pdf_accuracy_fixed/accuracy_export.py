import csv, re, sqlite3, subprocess, os, unicodedata, sys
from pathlib import Path
from PIL import Image

PDF='/mnt/data/612393_com_1129_male_without_photo_63_2025-11-24.pdf'
BASE_CSV='/mnt/data/voter_export (1).csv'
AREA_ASCII='2393'
OUT_CSV='/mnt/data/2393.csv'
OUT_DB='/mnt/data/2393.db'
REPORT='/mnt/data/2393_review_report.csv'
RENDER_DIR=Path('/mnt/data/ocr_pages_2393_200')
RENDER_DIR.mkdir(exist_ok=True)
headers=['ক্রমিক নং','ভোটার নং','নাম','পিতা','মাতা','পেশা','জন্ম তারিখ','ঠিকানা']

def digit_ascii(x):
    out=[]
    for ch in str(x):
        try: out.append(str(unicodedata.digit(ch)))
        except Exception: out.append(ch)
    return ''.join(out)

def bn_int(s):
    d=re.sub(r'\D','',digit_ascii(s))
    return int(d) if d else None

# conservative cleanup for old CSV embedded text extraction
REPL_ORDERED=[
    ('ছাĔ/ছাĔী','ছাত্র/ছাত্রী'), ('Řিমক','শ্রমিক'), ('িশÙক','শিক্ষক'), ('বËবসা','ব্যবসা'), ('অįাį','অন্যান্য'), ('ăাইভার','ড্রাইভার'), ('অবসরĴাİ','অবসরপ্রাপ্ত'), ('ইিýিনয়ার','ইঞ্জিনিয়ার'),
    ('আĺুছ','আব্দুছ'), ('আĺুস','আব্দুস'), ('আĺুল','আব্দুল'), ('আĺুর','আব্দুর'), ('আĺু','আব্দু'),
    ('আবƃর','আব্দুর'), ('আবƃল','আব্দুল'),
    ('উিėন','উদ্দিন'), ('উėীন','উদ্দীন'),
    ('Ïমাছাঃ','মোছাঃ'), ('Ïমাসাঃ','মোসাঃ'), ('Ïমাঃ','মোঃ'),
    ('Ïমেহ','মেহ'), ('Ïজৗ','জৌ'), ('ÏĨছা','নেছা'), ('Ïনছা','নেছা'), ('Ïব','বে'), ('Ïস','সে'), ('Ïর','রে'), ('Ïহ','হে'), ('Ïখ','খে'), ('Ïজ','জে'), ('Ïম','মে'), ('Ïল','লে'),
    ('Ř','শ্র'), ('Ĕ','ত্র'), ('ƃ','দ'), ('Ë','্য'), ('ė','দ্দ'), ('Ō','ল্ল'), ('Ň','ম্ম'), ('õ','জ্জ'), ('ļ','ব্ব'), ('ũ','স্ত'), ('Î','র্'), ('ý','ঞ্জ'), ('ē','ত্ত'), ('Ù','ক্ষ'), ('ê','ঙ্গ'), ('Ñ','ক্ক'), ('û','ঞ্চ'), ('î','চ্চ'), ('Ů','স্ব'), ('Ģ','ন্ত'), ('Ő','ল্প'), ('į','ন্য'), ('Ĵ','প্র'), ('ń','ম্ব'), ('Ðস','সৈ'), ('Ðশ','শৈ'), ('Ðত','তৈ'), ('Ðম','মৈ'), ('Ð','ৈ'), ('ę','দ্দ'),
    ('Ɓ','রু'), ('ƣ','কু'), ('ƀ','সু'), ('Ƅ','শু'), ('Ɔ','হু'), ('ſর','নূর'), ('বাſ','বানু'),
]
CONS='কখগঘঙচছজঝঞটঠডঢণতথদধনপফবভমযরলশষসহড়ঢ়য়'
PRE='িেৈোৌ'
pre_pat=re.compile(r'(^|[^'+re.escape(CONS)+r'])(['+re.escape(PRE)+r'])(['+re.escape(CONS)+r'])')
def reorder_prebase(s):
    prev=None
    while prev!=s:
        prev=s
        s=pre_pat.sub(lambda m:m.group(1)+m.group(3)+m.group(2),s)
    return s

def clean_base(s):
    if s is None: return ''
    s=str(s)
    for a,b in REPL_ORDERED: s=s.replace(a,b)
    s=reorder_prebase(s)
    s=s.replace('ো','ো').replace('ৌ','ৌ')
    # common post fixes from this voter-list font
    for a,b in {
        'শ্রিমক':'শ্রমিক','রিফক':'রফিক','ফিরদ':'ফরিদ','জিরনা':'জরিনা','তিমজ':'তমিজ','ময়মনসংহি':'ময়মনসিংহ',
        'এনায়েত':'এনায়েত','হোসেন':'হোসেন','বসরকারী':'বেসরকারী','জুয়লে':'জুয়েল','হাশেম':'হাশেম'
    }.items(): s=s.replace(a,b)
    s=re.sub(r'\s+',' ',s).strip(' ,')
    return s

def clean_ocr(s):
    if not s: return ''
    s=s.replace('মৌঃ','মোঃ').replace('মেঃ','মোঃ').replace('মােঃ','মোঃ')
    s=s.replace('_',' ').replace('  ',' ')
    s=s.replace('নং.', 'নং:').replace('নং ', 'নং: ')
    s=s.replace(' ,', ',').replace('।','')
    s=re.sub(r'\s+',' ',s).strip(' :-,')
    return s

# Load base rows from previous export, then OCR will overwrite reliable fields.
records={}
with open(BASE_CSV,encoding='utf-8-sig',newline='') as f:
    for r in csv.DictReader(f):
        if digit_ascii(r.get('voter_area_no',''))==AREA_ASCII:
            serial=bn_int(r.get('serial_text'))
            if not serial: continue
            records[serial]={
                'ক্রমিক নং': clean_base(r.get('serial_text','')),
                'ভোটার নং': clean_base(r.get('voter_no','')),
                'নাম': clean_base(r.get('name','')),
                'পিতা': clean_base(r.get('father','')),
                'মাতা': clean_base(r.get('mother','')),
                'পেশা': clean_base(r.get('occupation','')),
                'জন্ম তারিখ': clean_base(r.get('birth_date','')),
                'ঠিকানা': clean_base(r.get('address','')),
                '_source':'base'
            }

# Render pages if not already present
# Page 1-2 are cover/blank; actual list starts page 3.
if not (RENDER_DIR/'p-03.png').exists():
    subprocess.run(['pdftoppm','-f','3','-l','64','-png','-r','200',PDF,str(RENDER_DIR/'p')],check=True)

serial_line_re=re.compile(r'(?=(\d{4}|[০-৯]{4})\.\s*নাম\s*:)')
def split_serial_line(line):
    parts=[]
    starts=[m.start() for m in serial_line_re.finditer(line)]
    for i,st in enumerate(starts):
        en=starts[i+1] if i+1<len(starts) else len(line)
        seg=line[st:en].strip()
        m=re.match(r'([০-৯0-9]{4})\.\s*নাম\s*[:：]?\s*(.+)',seg)
        if m: parts.append((bn_int(m.group(1)), clean_ocr(m.group(2))))
    return parts

def split_label_line(line,label):
    # returns values after each label occurrence up to next same label
    pat=re.compile(re.escape(label)+r'\s*[:：.]?\s*')
    starts=[m.start() for m in pat.finditer(line)]
    vals=[]
    if starts:
        matches=list(pat.finditer(line))
        for i,m in enumerate(matches):
            st=m.end(); en=matches[i+1].start() if i+1<len(matches) else len(line)
            vals.append(clean_ocr(line[st:en]))
    return vals

def parse_ocr_page(text):
    current=[]
    for raw in text.splitlines():
        line=clean_ocr(raw)
        if not line: continue
        serials=split_serial_line(line)
        if serials:
            current=[s for s,n in serials]
            for s,n in serials:
                if s in records and n and len(n)>=2:
                    records[s]['নাম']=n; records[s]['_source']='ocr+base'
            continue
        if not current: continue
        # voter no
        vals=split_label_line(line,'ভোটার নং')
        if vals:
            # strip to digits
            nums=[]
            for v in vals:
                m=re.search(r'[০-৯0-9]{8,}',v)
                nums.append(m.group(0) if m else v)
            for s,v in zip(current,nums):
                if s in records and v: records[s]['ভোটার নং']=clean_ocr(v); records[s]['_source']='ocr+base'
            continue
        for label,outkey in [('পিতা','পিতা'),('মাতা','মাতা')]:
            vals=split_label_line(line,label)
            if vals:
                for s,v in zip(current,vals):
                    if s in records and v and len(v)>1:
                        records[s][outkey]=v; records[s]['_source']='ocr+base'
                break
        else:
            vals=split_label_line(line,'পেশা')
            if vals:
                for s,v in zip(current,vals):
                    if s in records and v:
                        # split occupation and birth date
                        parts=re.split(r'জন্ম\s*তারিখ\s*[:：]?',v,1)
                        occ=parts[0].strip(' ,')
                        bd=parts[1].strip(' ,') if len(parts)>1 else ''
                        if occ: records[s]['পেশা']=occ
                        if bd: records[s]['জন্ম তারিখ']=bd
                        records[s]['_source']='ocr+base'
                continue
            vals=split_label_line(line,'ঠিকানা')
            if vals:
                for s,v in zip(current,vals):
                    if s in records and v and len(v)>4:
                        records[s]['ঠিকানা']=v; records[s]['_source']='ocr+base'
                continue

# OCR all rendered pages. Use psm 4 because it preserves column lines better than psm 6 for this list.
page_files=sorted(RENDER_DIR.glob('p-*.png'))
for i,p in enumerate(page_files,1):
    try:
        out=subprocess.run(['tesseract',str(p),'stdout','-l','ben','--psm','4'],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,timeout=20)
        text=out.stdout.decode('utf-8','replace')
        parse_ocr_page(text)
        if i%10==0: print('ocr pages',i,'/',len(page_files), file=sys.stderr)
    except subprocess.TimeoutExpired:
        print('ocr timeout',p,file=sys.stderr)

# Apply safe final clean to all fields after OCR overlay. Do not reorder vowel signs here,
# because OCR text is already in correct Unicode order (e.g., জুয়েল, এনায়েত).
def clean_final(s):
    if s is None: return ''
    s=str(s)
    for a,b in REPL_ORDERED:
        s=s.replace(a,b)
    s=s.replace('ো','ো').replace('ৌ','ৌ').replace('_',' ')
    for a,b in {
        'শ্রিমক':'শ্রমিক','রিফক':'রফিক','ফিরদ':'ফরিদ','তিমজ':'তমিজ','বসরকারী':'বেসরকারী',
        'ময়মনসংহি':'ময়মনসিংহ','হোসেন':'হোসেন','হোসাইন':'হোসাইন','জুয়লে':'জুয়েল','এনায়তে':'এনায়েত',
        'মমতাজ,বেগম':'মমতাজ বেগম','সনজিতা, বেগম':'সনজিতা বেগম'
    }.items():
        s=s.replace(a,b)
    s=re.sub(r'\s+',' ',s).strip(' ,')
    return s

final=[]
for serial in sorted(records):
    r=records[serial]
    row={h: clean_final(r.get(h,'')) for h in headers}
    final.append(row)

# Write CSV with exact required columns.
with open(OUT_CSV,'w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=headers)
    w.writeheader(); w.writerows(final)

# DB with Bengali column names.
p=Path(OUT_DB)
if p.exists(): p.unlink()
conn=sqlite3.connect(OUT_DB)
conn.execute('CREATE TABLE voters ('+', '.join([f'"{h}" TEXT' for h in headers])+')')
conn.executemany('INSERT INTO voters VALUES ('+','.join(['?']*len(headers))+')', [[r[h] for h in headers] for r in final])
for h in ['ভোটার নং','নাম','পিতা','মাতা']:
    conn.execute(f'CREATE INDEX idx_{headers.index(h)} ON voters("{h}")')
conn.commit(); conn.close()

# Report potential unresolved artifacts or missing values.
def suspicious(v):
    if not v: return True
    for ch in v:
        if ch in ' .,-/:()।': continue
        try: unicodedata.digit(ch); continue
        except Exception: pass
        if not ('\u0980' <= ch <= '\u09ff'):
            return True
    return False
bad=[]
for r in final:
    for h in headers:
        if suspicious(r[h]): bad.append({'ক্রমিক নং':r['ক্রমিক নং'],'field':h,'value':r[h]})
with open(REPORT,'w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=['ক্রমিক নং','field','value'])
    w.writeheader(); w.writerows(bad)
print('records',len(final),'bad_fields',len(bad))
print('first15')
for r in final[:15]: print(r)
