import csv
import hashlib
import os
import re
import shutil
import subprocess
import tempfile
import zipfile
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, List, Optional, Tuple

try:
    import fitz  # PyMuPDF
except Exception:  # pragma: no cover
    fitz = None

BN_TO_ASCII = str.maketrans("০১২৩৪৫৬৭৮৯", "0123456789")
ASCII_TO_BN = str.maketrans("0123456789", "০১২৩৪৫৬৭৮৯")

# Common artifacts seen in Election Commission Bangla PDFs. Keep raw text in DB too.
COMMON_FIXES = {
    "Ïভাটার": "ভোটার",
    "Ïজলা": "জেলা",
    "Ïপশা": "পেশা",
    "িপতা": "পিতা",
    "মাতা": "মাতা",
    "িঠকানা": "ঠিকানা",
    "জĥ": "জন্ম",
    "Ĵকােশর": "প্রকাশের",
    "তািরখ": "তারিখ",
    "উপেজলা": "উপজেলা",
    "ঈśরগý": "ঈশ্বরগঞ্জ",
    "ময়মনিসংহ": "ময়মনসিংহ",
    "নńর": "নম্বর",
    "ইউিনয়ন": "ইউনিয়ন",
    "মিহলা": "মহিলা",
    "সবÎেমাট": "সর্বমোট",
    "সংখËা": "সংখ্যা",
    "কেপÎােরশন": "কর্পোরেশন",
    "Ïকাড": "কোড",
    "ওয়াডÎ": "ওয়ার্ড",
    "িনবÎাচন": "নির্বাচন",
    "বোডÎ": "বোর্ড",
    "কËাটনেমট": "ক্যান্টনমেন্ট",
    "তািলকা": "তালিকা",
    "আ×ার": "আক্তার",
    "উিėন": "উদ্দিন",
    "আĺুল": "আব্দুল",
    "আĺুর": "আব্দুর",
    "আĺুস": "আব্দুস",
    "আĺুŌাহ": "আব্দুল্লাহ",
    "মডল": "মন্ডল",
    "মড়ল": "মন্ডল",
    "বাſ": "বানু",
    "ƀ": "সু",
    "ſর": "নূর",
    "Ɓ": "রু",
    "ƣ": "কু",
    "Ƅ": "শু",
    "Ɔ": "হু",
    "◌্": "",
    "": "",
}

# This leading marker often represents a pre-base vowel. This map is intentionally conservative.
LEADING_GLYPH_FIXES = {
    "Ïমা": "মো", "Ïমাঃ": "মোঃ", "Ïমাছাঃ": "মোছাঃ", "Ïমাসাঃ": "মোসাঃ",
    "Ïমাছ": "মোছ", "Ïমাস": "মোস", "Ïমা": "মো",
    "Ïব": "বে", "Ïস": "সে", "Ïর": "রে", "Ïহ": "হে", "Ïন": "নে",
    "Ïখা": "খো", "Ïজা": "জো", "Ïজে": "জে", "Ïচা": "চো", "Ïদ": "দে",
    "Ïপা": "পো", "Ïপৗ": "পৌ", "Ïপ": "পে", "Ïগা": "গো", "Ïরা": "রো",
    "Ïলা": "লো", "Ïশ": "শে", "Ïছা": "ছো", "Ïতা": "তো", "Ïকা": "কো",
    "Ðসয়দ": "সৈয়দ",
    "Ðজ": "জৈ",
}

FIELD_KEYS = ["name", "voter_no", "father", "mother", "occupation", "birth_date", "address"]


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def bangla_to_ascii_digits(value: str) -> str:
    return (value or "").translate(BN_TO_ASCII)


def ascii_to_bangla_digits(value: str) -> str:
    return (value or "").translate(ASCII_TO_BN)


def clean_text(text: str) -> str:
    if not text:
        return ""
    text = text.replace("\r", "\n")
    for src, dst in LEADING_GLYPH_FIXES.items():
        text = text.replace(src, dst)
    for src, dst in COMMON_FIXES.items():
        text = text.replace(src, dst)
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def clean_value(value: str) -> str:
    value = clean_text(value or "")
    value = value.strip(" \t:-,।")
    value = re.sub(r"\s+", " ", value)
    return value


def normalize_search(value: str) -> str:
    value = clean_text(value or "")
    value = bangla_to_ascii_digits(value)
    value = value.lower()
    # Remove common prefixes/titles for forgiving search.
    for token in ["মোছাঃ", "মোসাঃ", "মোঃ", "মোছা", "মোসা", "মৃত-", "মৃত", ":", "।", ",", ".", "-", "_"]:
        value = value.replace(token, " ")
    value = re.sub(r"\s+", " ", value).strip()
    return value


def extract_text_with_pages(pdf_path: Path) -> List[Tuple[int, str]]:
    """Return list of (1-based page_no, text).

    PyMuPDF is preferred for this voter-list format because poppler's layout mode
    may merge multi-column records into one line. If PyMuPDF is unavailable,
    fall back to pdftotext without -layout.
    """
    if fitz is not None:
        doc = fitz.open(str(pdf_path))
        pages = []
        for i, page in enumerate(doc):
            text = page.get_text("text")
            if text.strip():
                pages.append((i + 1, text))
        if pages:
            return pages
    if shutil.which("pdftotext"):
        with tempfile.TemporaryDirectory() as td:
            out = Path(td) / "out.txt"
            cmd = ["pdftotext", "-enc", "UTF-8", str(pdf_path), str(out)]
            subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            text = out.read_text("utf-8", errors="replace")
            pages = text.split("\f")
            return [(i + 1, p) for i, p in enumerate(pages) if p.strip()]
    raise RuntimeError("No PDF text extractor available. Install PyMuPDF or poppler-utils.")


def extract_meta(full_text: str) -> Dict[str, str]:
    text = clean_text(full_text)
    meta = {}
    def first(patterns):
        for pat in patterns:
            m = re.search(pat, text, flags=re.MULTILINE)
            if m:
                return clean_value(m.group(1))
        return ""
    meta["district"] = first([r"জেলা[: ]+([^\n]+)"])
    meta["upazila"] = first([r"উপজেলা/থানা[: ]+([^\n]+)", r"উপজেলা[: ]+([^\n]+)"])
    meta["union_name"] = first([r"ইউনিয়ন[/ ]*ওয়ার্ড[/ ]*ক্যা[^:：]*[:： ]+([^\n]+)", r"ইউনিয়ন[: ]+([^\n]+)"])
    if (not meta["union_name"]) or ("পিরষেদর" in meta["union_name"] or "পরিষদ" in meta["union_name"]):
        # Cover title page layout where union name is on the next isolated line.
        m = re.search(r"ইউনিয়ন/.*?বোর্ড\s*\n\s*([^\n]+)", text, flags=re.S)
        meta["union_name"] = clean_value(m.group(1)) if m else ""
    meta["ward_no"] = first([r"ওয়ার্ড ন(?:ং|ম্বর).*?[: ]+([০-৯0-9]+)"])
    meta["voter_area"] = first([r"ভোটার এলাকার নাম[: ]+([^\n]+)", r"ভোটার এলাকা\s+([^\n]+)"])
    meta["voter_area_no"] = first([r"ভোটার এলাকার ন(?:ং|ম্বর)[: ]+([০-৯0-9]+)"])
    meta["published_date"] = first([r"প্রকাশের তারিখ[: ]+([০-৯0-9/\-]+)"])
    meta["list_gender"] = "মহিলা" if "ভোটার তালিকা - (মহিলা)" in text or "মহিলা" in text[:1500] else ""
    return meta


@dataclass
class VoterRecord:
    pdf_page: Optional[int]
    list_page: Optional[int]
    serial_text: str
    serial_no: Optional[int]
    voter_no: str
    voter_no_ascii: str
    name: str
    father: str
    mother: str
    occupation: str
    birth_date: str
    address: str
    raw_record: str
    confidence: int
    needs_review: int


def _find_value(block: str, label_variants: List[str], stop_labels: List[str]) -> str:
    # Works across line breaks until the next known label.
    labels = "|".join(re.escape(x) for x in label_variants)
    stops = "|".join(re.escape(x) for x in stop_labels)
    m = re.search(rf"(?:{labels})\s*[:：]\s*(.*?)(?=\n\s*(?:{stops})\s*[:：]|\Z)", block, flags=re.S)
    if not m:
        return ""
    value = m.group(1).strip()
    return clean_value(value)


def parse_record_block(page_no: int, block: str) -> Optional[VoterRecord]:
    raw = block.strip()
    cleaned = clean_text(raw)
    m = re.match(r"^\s*([০-৯0-9]{1,5})\s*\.\s*নাম\s*[:：]\s*(.+?)\s*(?:\n|$)", cleaned, flags=re.S)
    if not m:
        return None
    serial_text = clean_value(m.group(1))
    serial_no = None
    try:
        serial_no = int(bangla_to_ascii_digits(serial_text))
    except Exception:
        pass
    name = clean_value(m.group(2).split("\n")[0])
    stop_labels = ["ভোটার নং", "ভোটার নং", "পিতা", "মাতা", "পেশা", "জন্ম তারিখ", "ঠিকানা"]
    voter_no = _find_value(cleaned, ["ভোটার নং", "ভোটার নং"], ["পিতা", "মাতা", "পেশা", "জন্ম তারিখ", "ঠিকানা"])
    father = _find_value(cleaned, ["পিতা"], ["মাতা", "পেশা", "জন্ম তারিখ", "ঠিকানা"])
    mother = _find_value(cleaned, ["মাতা"], ["পেশা", "জন্ম তারিখ", "ঠিকানা"])

    occupation = ""
    birth_date = ""
    m2 = re.search(r"পেশা\s*[:：]\s*(.*?)(?:,\s*জন্ম\s*তারিখ\s*[:：]?\s*([^\n]+))?(?=\n\s*ঠিকানা\s*[:：]|\Z)", cleaned, flags=re.S)
    if m2:
        occupation = clean_value(m2.group(1) or "")
        birth_date = clean_value(m2.group(2) or "")
    if not birth_date:
        m3 = re.search(r"জন্ম\s*তারিখ\s*[:：]?\s*([০-৯0-9/\-]+)", cleaned)
        birth_date = clean_value(m3.group(1)) if m3 else ""

    address = _find_value(cleaned, ["ঠিকানা"], ["নাম", "ভোটার নং", "পিতা", "মাতা", "পেশা"])
    # Drop page footers/signature text that may be captured after the last record on a page.
    address = re.sub(r"\s+[০-৯0-9]{1,4}\s+(?:রেিজ|রেজি|Registration|অিফসার|অফিসার).*$", "", address, flags=re.I).strip()
    address = re.sub(r"\s+(?:রেিজ|রেজি).*?(?:অিফসার|অফিসার).*$", "", address).strip()
    address = re.sub(r"\s+[০-৯0-9]{1,3}\s*$", "", address).strip()

    voter_ascii = re.sub(r"\D", "", bangla_to_ascii_digits(voter_no))
    required = [serial_text, name, voter_ascii, father, mother, birth_date, address]
    found = sum(1 for x in required if x)
    confidence = int(round(found / len(required) * 100))
    if voter_ascii and len(voter_ascii) not in (10, 11, 12, 13, 17):
        confidence -= 10
    if re.search(r"[ÏÎËÐƁƀƣƄƆƇƊƋƌƍƎƏƑƒƓƔƕƖƗƘƙƚƛƜƝƞƟƢƤƥƦƧƨƩƪƫƬƭƮƯưƱƲƳƴƵƶƷƸƹƺƻƼƽƾƿ]", cleaned):
        confidence -= 5
    confidence = max(0, min(100, confidence))
    needs_review = 1 if confidence < 95 else 0

    return VoterRecord(
        pdf_page=page_no,
        list_page=None,
        serial_text=serial_text,
        serial_no=serial_no,
        voter_no=voter_no,
        voter_no_ascii=voter_ascii,
        name=name,
        father=father,
        mother=mother,
        occupation=occupation,
        birth_date=birth_date,
        address=address,
        raw_record=raw,
        confidence=confidence,
        needs_review=needs_review,
    )


def parse_voters_from_pages(pages: List[Tuple[int, str]]) -> Tuple[Dict[str, str], List[VoterRecord]]:
    full_text = "\n".join(p for _, p in pages)
    meta = extract_meta(full_text)
    records: List[VoterRecord] = []
    serial_start_re = re.compile(r"(?m)^\s*[০-৯0-9]{1,5}\s*\.\s*নাম\s*[:：]")
    for page_no, page_text in pages:
        text = clean_text(page_text)
        matches = list(serial_start_re.finditer(text))
        for i, match in enumerate(matches):
            start = match.start()
            end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
            block = text[start:end]
            rec = parse_record_block(page_no, block)
            if rec:
                # Footer list page usually appears as last numeric line. Keep nullable for safety.
                footer = re.findall(r"(?m)^\s*([০-৯0-9]{1,4})\s*$", text[-200:])
                if footer:
                    try:
                        rec.list_page = int(bangla_to_ascii_digits(footer[-1]))
                    except Exception:
                        rec.list_page = None
                records.append(rec)
    return meta, records


def extract_pdf(pdf_path: Path) -> Tuple[Dict[str, str], List[VoterRecord]]:
    pages = extract_text_with_pages(pdf_path)
    if not pages:
        raise RuntimeError("No extractable text found. This may be a scanned PDF; OCR is required.")
    return parse_voters_from_pages(pages)


def records_to_db_rows(records: List[VoterRecord], file_id: int, source_file: str, meta: Dict[str, str]) -> List[Dict[str, object]]:
    rows = []
    for rec in records:
        d = asdict(rec)
        d.update(meta)
        d["file_id"] = file_id
        d["source_file"] = source_file
        search_parts = [
            d.get("serial_text"), d.get("voter_no"), d.get("voter_no_ascii"), d.get("name"),
            d.get("father"), d.get("mother"), d.get("birth_date"), d.get("address"),
            d.get("district"), d.get("upazila"), d.get("union_name"), d.get("voter_area"), d.get("voter_area_no")
        ]
        d["search_blob"] = normalize_search(" ".join(str(x or "") for x in search_parts))
        rows.append(d)
    return rows


def extract_pdfs_from_zip(zip_path: Path, out_dir: Path) -> List[Path]:
    pdfs = []
    with zipfile.ZipFile(zip_path) as z:
        for info in z.infolist():
            if info.is_dir():
                continue
            name = Path(info.filename).name
            if not name.lower().endswith(".pdf"):
                continue
            target = out_dir / name
            base = target.stem
            suffix = target.suffix
            counter = 1
            while target.exists():
                target = out_dir / f"{base}_{counter}{suffix}"
                counter += 1
            with z.open(info) as src, target.open("wb") as dst:
                shutil.copyfileobj(src, dst)
            pdfs.append(target)
    return pdfs
