"""Command-line bulk importer for folders of PDF/ZIP files.

Usage:
    python bulk_import.py /path/to/folder
"""
from pathlib import Path
import sys
import tempfile

import db
from extractor import extract_pdf, extract_pdfs_from_zip, records_to_db_rows, sha256_file


def import_one(path: Path):
    file_hash = sha256_file(path)
    meta = {
        "filename": path.name,
        "saved_path": str(path),
        "sha256": file_hash,
        "status": "processing",
        "error": None,
        "total_records": 0,
    }
    try:
        file_id = db.insert_imported_file(meta)
    except Exception:
        print(f"SKIP duplicate: {path.name}")
        return
    try:
        pdf_meta, records = extract_pdf(path)
        rows = records_to_db_rows(records, file_id, path.name, pdf_meta)
        inserted = db.insert_voters(rows)
        db.update_imported_file(file_id, status="imported", total_records=inserted, **pdf_meta)
        print(f"OK {path.name}: {inserted} records")
    except Exception as e:
        db.update_imported_file(file_id, status="failed", error=str(e))
        print(f"FAIL {path.name}: {e}")


def main():
    if len(sys.argv) < 2:
        print("Usage: python bulk_import.py /path/to/folder-or-file")
        raise SystemExit(1)
    db.init_db()
    root = Path(sys.argv[1]).expanduser().resolve()
    files = []
    if root.is_file():
        files = [root]
    else:
        files = sorted([p for p in root.rglob("*") if p.suffix.lower() in (".pdf", ".zip")])
    with tempfile.TemporaryDirectory() as td:
        temp_dir = Path(td)
        for f in files:
            if f.suffix.lower() == ".zip":
                for pdf in extract_pdfs_from_zip(f, temp_dir):
                    import_one(pdf)
            else:
                import_one(f)


if __name__ == "__main__":
    main()
