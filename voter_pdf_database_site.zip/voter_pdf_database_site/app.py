import csv
import io
import os
import shutil
from pathlib import Path
from typing import List

from flask import Flask, Response, flash, redirect, render_template, request, send_file, url_for
from werkzeug.utils import secure_filename

import db
from extractor import extract_pdf, extract_pdfs_from_zip, records_to_db_rows, sha256_file, bangla_to_ascii_digits

BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "uploads"
EXPORT_DIR = BASE_DIR / "exports"
ALLOWED = {".pdf", ".zip"}

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-this-secret-key")
app.config["MAX_CONTENT_LENGTH"] = int(os.environ.get("MAX_UPLOAD_MB", "512")) * 1024 * 1024


def allowed_file(filename: str) -> bool:
    return Path(filename).suffix.lower() in ALLOWED


@app.before_request
def _init():
    db.init_db()
    UPLOAD_DIR.mkdir(exist_ok=True)
    EXPORT_DIR.mkdir(exist_ok=True)


@app.route("/")
def index():
    return render_template("index.html", stats=db.get_stats())


@app.route("/upload", methods=["GET", "POST"])
def upload():
    if request.method == "GET":
        return render_template("upload.html")
    files = request.files.getlist("files")
    if not files or all(not f.filename for f in files):
        flash("ফাইল সিলেক্ট করা হয়নি।", "error")
        return redirect(url_for("upload"))

    saved: List[Path] = []
    for f in files:
        if not f.filename or not allowed_file(f.filename):
            continue
        filename = secure_filename(f.filename)
        if not filename:
            filename = "upload.pdf"
        target = UPLOAD_DIR / filename
        stem, suffix = target.stem, target.suffix
        counter = 1
        while target.exists():
            target = UPLOAD_DIR / f"{stem}_{counter}{suffix}"
            counter += 1
        f.save(target)
        if target.suffix.lower() == ".zip":
            saved.extend(extract_pdfs_from_zip(target, UPLOAD_DIR))
        else:
            saved.append(target)

    results = []
    for path in saved:
        file_hash = sha256_file(path)
        meta = {
            "filename": path.name,
            "saved_path": str(path),
            "sha256": file_hash,
            "status": "processing",
            "error": None,
            "total_records": 0,
        }
        try:
            file_id = db.insert_imported_file(meta)
        except Exception:
            # Duplicate hash. Do not re-import.
            results.append({"filename": path.name, "status": "duplicate", "records": 0, "error": "এই ফাইলটি আগে import করা আছে।"})
            continue
        try:
            pdf_meta, records = extract_pdf(path)
            rows = records_to_db_rows(records, file_id, path.name, pdf_meta)
            inserted = db.insert_voters(rows)
            db.update_imported_file(file_id, status="imported", total_records=inserted, **pdf_meta)
            results.append({"filename": path.name, "status": "imported", "records": inserted, "error": None})
        except Exception as e:
            db.update_imported_file(file_id, status="failed", error=str(e))
            results.append({"filename": path.name, "status": "failed", "records": 0, "error": str(e)})
    return render_template("upload_result.html", results=results)


@app.route("/search")
def search():
    q = request.args.get("q", "").strip()
    name = request.args.get("name", "").strip()
    father = request.args.get("father", "").strip()
    mother = request.args.get("mother", "").strip()
    voter_no = request.args.get("voter_no", "").strip()
    limit = min(int(request.args.get("limit", "100") or 100), 1000)
    rows = []
    if any([q, name, father, mother, voter_no]):
        rows = db.search_voters(q=q, name=name, father=father, mother=mother, voter_no=voter_no, limit=limit)
    return render_template("search.html", rows=rows, params=request.args)


@app.route("/review")
def review():
    with db.get_conn() as conn:
        rows = conn.execute(
            """
            SELECT voters.*, imported_files.filename AS imported_filename
            FROM voters
            JOIN imported_files ON imported_files.id=voters.file_id
            WHERE needs_review=1
            ORDER BY confidence ASC, voters.id DESC
            LIMIT 300
            """
        ).fetchall()
    return render_template("review.html", rows=rows)


@app.route("/record/<int:record_id>", methods=["GET", "POST"])
def edit_record(record_id: int):
    with db.get_conn() as conn:
        if request.method == "POST":
            fields = ["name", "father", "mother", "voter_no", "occupation", "birth_date", "address"]
            values = {f: request.form.get(f, "").strip() for f in fields}
            values["voter_no_ascii"] = bangla_to_ascii_digits(values["voter_no"])
            values["needs_review"] = 0 if request.form.get("mark_ok") else 1
            conn.execute(
                """
                UPDATE voters
                SET name=:name, father=:father, mother=:mother, voter_no=:voter_no,
                    voter_no_ascii=:voter_no_ascii, occupation=:occupation, birth_date=:birth_date,
                    address=:address, needs_review=:needs_review, updated_at=CURRENT_TIMESTAMP
                WHERE id=:id
                """,
                {**values, "id": record_id},
            )
            flash("রেকর্ড আপডেট হয়েছে।", "success")
            return redirect(url_for("edit_record", record_id=record_id))
        row = conn.execute("SELECT * FROM voters WHERE id=?", [record_id]).fetchone()
    if not row:
        flash("রেকর্ড পাওয়া যায়নি।", "error")
        return redirect(url_for("search"))
    return render_template("edit_record.html", row=row)


@app.route("/export/csv")
def export_csv():
    with db.get_conn() as conn:
        rows = conn.execute("SELECT * FROM voters ORDER BY source_file, serial_no").fetchall()
    headers = [
        "source_file", "pdf_page", "list_page", "serial_text", "serial_no", "voter_no", "voter_no_ascii",
        "name", "father", "mother", "occupation", "birth_date", "address", "district", "upazila",
        "union_name", "ward_no", "voter_area", "voter_area_no", "list_gender", "published_date",
        "confidence", "needs_review"
    ]
    output = io.StringIO()
    output.write("\ufeff")  # Excel-friendly UTF-8 BOM
    writer = csv.DictWriter(output, fieldnames=headers)
    writer.writeheader()
    for r in rows:
        writer.writerow({h: r[h] for h in headers})
    data = output.getvalue().encode("utf-8")
    return Response(
        data,
        mimetype="text/csv; charset=utf-8",
        headers={"Content-Disposition": "attachment; filename=voter_export.csv"},
    )


@app.route("/export/db")
def export_db():
    db.init_db()
    src = db.DB_PATH
    copy_path = EXPORT_DIR / "voter_data_export.db"
    # Make a stable copy while the app may be writing.
    with db.get_conn() as conn:
        backup = __import__("sqlite3").connect(copy_path)
        conn.backup(backup)
        backup.close()
    return send_file(copy_path, as_attachment=True, download_name="voter_data.db")


@app.route("/files")
def files():
    with db.get_conn() as conn:
        rows = conn.execute("SELECT * FROM imported_files ORDER BY id DESC").fetchall()
    return render_template("files.html", rows=rows)


if __name__ == "__main__":
    db.init_db()
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")), debug=True)
