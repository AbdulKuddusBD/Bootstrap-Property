# Voter PDF Database Site

Local-first web app for importing Election Commission-style voter list PDFs into a searchable SQLite database. It can export all records as CSV and `.db`.

## Features

- Upload many PDF files or a ZIP containing PDFs
- Extract fields: serial, voter no, name, father, mother, occupation, birth date, address
- Extract list metadata: district, upazila, union, ward, voter area, area code, publication date
- Search by name, father, mother, voter number, address, or any keyword
- Review low-confidence records and manually correct them
- Export UTF-8 CSV for Excel
- Export SQLite `.db` file
- Stores raw PDF text for audit/review

## Privacy and legal note

Voter lists contain personal data. Run this app locally or on a private server only, protect the database, and use it according to applicable law and authorization.

## Install

### 1) Create virtual environment

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### 2) Optional but recommended PDF text extractor

Linux:

```bash
sudo apt-get install poppler-utils
```

The app falls back to PyMuPDF if `pdftotext` is not installed.

### 3) Run

```bash
python app.py
```

Open:

```text
http://127.0.0.1:5000
```

## Export

- CSV: `/export/csv`
- SQLite DB: `/export/db`

## Accuracy workflow

1. Import PDFs.
2. Open `Review` page.
3. Check low-confidence records against raw PDF text.
4. Correct and mark OK.
5. Export CSV or DB.

## Folder structure

```text
app.py              Flask routes
extractor.py        PDF extraction and voter parser
db.py               SQLite schema and queries
templates/          HTML pages
static/style.css    UI style
uploads/            uploaded PDF/ZIP files
instance/           SQLite database
exports/            generated export copies
```

## Common issues

- If records are not extracted: the PDF may be scanned image-only. OCR is required first.
- If Bangla text looks strange: use the Review page. The parser keeps both cleaned fields and raw text.
- Duplicate PDF uploads are skipped using SHA-256 file hash.
