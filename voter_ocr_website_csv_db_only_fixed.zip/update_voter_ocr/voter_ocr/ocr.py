from __future__ import annotations

import os
import re
import tempfile
from dataclasses import dataclass
from pathlib import Path


@dataclass
class OCRResult:
    text: str
    confidence: float
    labels_found: int
    variant_name: str


LABELS = ["নাম", "ভোটার", "পিতা", "মাতা", "পেশা", "জন্ম", "ঠিকানা"]


def check_tesseract(lang: str = "ben+eng") -> tuple[bool, str]:
    try:
        import pytesseract
        version = pytesseract.get_tesseract_version()
        langs = set(pytesseract.get_languages(config=""))
        missing = []
        for item in lang.split("+"):
            if item and item not in langs:
                missing.append(item)
        if missing:
            return False, f"Tesseract found ({version}), but missing language data: {', '.join(missing)}"
        return True, f"Tesseract ready ({version}), languages OK: {lang}"
    except Exception as exc:
        return False, f"Tesseract/PyTesseract not ready: {exc}"


def _preprocess_variants(image_path: Path) -> list[tuple[str, object]]:
    import cv2

    image = cv2.imread(str(image_path))
    if image is None:
        raise RuntimeError(f"Could not read image: {image_path}")
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Fast/balanced mode: only two useful variants. Older project used many variants
    # and two separate Tesseract calls per variant, which can take many hours.
    up = cv2.resize(gray, None, fx=2.0, fy=2.0, interpolation=cv2.INTER_CUBIC)
    variants: list[tuple[str, object]] = [("gray_2x", up)]

    ad = cv2.adaptiveThreshold(up, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 35, 11)
    variants.append(("adaptive_2x", ad))
    return variants


def _text_from_data(data: dict) -> str:
    words = data.get("text", []) or []
    block_nums = data.get("block_num", []) or []
    par_nums = data.get("par_num", []) or []
    line_nums = data.get("line_num", []) or []
    rows: list[tuple[tuple[int, int, int], str]] = []
    for i, word in enumerate(words):
        word = str(word).strip()
        if not word:
            continue
        key = (
            int(block_nums[i]) if i < len(block_nums) else 0,
            int(par_nums[i]) if i < len(par_nums) else 0,
            int(line_nums[i]) if i < len(line_nums) else 0,
        )
        rows.append((key, word))
    lines: list[str] = []
    current_key = None
    current_words: list[str] = []
    for key, word in rows:
        if current_key is None:
            current_key = key
        if key != current_key:
            lines.append(" ".join(current_words))
            current_words = []
            current_key = key
        current_words.append(word)
    if current_words:
        lines.append(" ".join(current_words))
    return "\n".join(lines)


def _ocr_image_array(image, lang: str, psm: int, timeout: int = 45) -> OCRResult:
    import cv2
    import pytesseract

    config = f"--oem 1 --psm {psm} -c preserve_interword_spaces=1"
    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
        temp_path = tmp.name
    try:
        cv2.imwrite(temp_path, image)
        # One Tesseract call only. image_to_data gives both words and confidence.
        data = pytesseract.image_to_data(
            temp_path,
            lang=lang,
            config=config,
            output_type=pytesseract.Output.DICT,
            timeout=timeout,
        )
        text = _text_from_data(data)
        confs = []
        for c in data.get("conf", []):
            try:
                val = float(c)
                if val >= 0:
                    confs.append(val)
            except Exception:
                pass
        confidence = sum(confs) / len(confs) if confs else 0.0
        labels_found = sum(1 for label in LABELS if label in text)
        return OCRResult(text=text, confidence=confidence, labels_found=labels_found, variant_name="")
    finally:
        try:
            os.unlink(temp_path)
        except OSError:
            pass


def run_ocr(image_path: Path, lang: str = "ben+eng") -> OCRResult:
    """Run Bengali OCR in faster balanced mode and choose the best variant."""
    try:
        import pytesseract  # noqa: F401
    except Exception as exc:  # pragma: no cover
        raise RuntimeError("pytesseract missing. Run: pip install -r requirements.txt") from exc

    best: OCRResult | None = None
    best_score = -1.0
    for name, img in _preprocess_variants(image_path):
        for psm in (6,):
            try:
                result = _ocr_image_array(img, lang=lang, psm=psm, timeout=45)
            except RuntimeError as exc:
                result = OCRResult(text=f"OCR_TIMEOUT_OR_ERROR: {exc}", confidence=0.0, labels_found=0, variant_name=f"{name}_psm{psm}")
            result.variant_name = f"{name}_psm{psm}"
            text_len = len(re.sub(r"\s+", "", result.text))
            score = result.labels_found * 1000 + result.confidence * 10 + min(text_len, 250)
            if best is None or score > best_score:
                best = result
                best_score = score
    return best or OCRResult("", 0.0, 0, "none")


@dataclass
class OCRWord:
    text: str
    left: int
    top: int
    width: int
    height: int
    confidence: float
    block_num: int = 0
    par_num: int = 0
    line_num: int = 0
    word_num: int = 0

    @property
    def cx(self) -> float:
        return self.left + self.width / 2.0

    @property
    def cy(self) -> float:
        return self.top + self.height / 2.0


def run_page_ocr_words(image_path: Path, lang: str = "ben+eng", psm: int = 6, timeout: int = 35) -> tuple[list[OCRWord], float, str]:
    """Run OCR once for a whole page and return word boxes.

    This is the ultra-fast path. Instead of calling Tesseract for every voter
    card, we call it once per rendered page, then split words by detected card
    rectangles. For pages with 15 cards, this can be 8-15x faster.
    """
    try:
        import cv2
        import pytesseract
    except Exception as exc:  # pragma: no cover
        raise RuntimeError("pytesseract/opencv missing. Run: pip install -r requirements.txt") from exc

    image = cv2.imread(str(image_path))
    if image is None:
        raise RuntimeError(f"Could not read image: {image_path}")

    # Keep original size so TSV coordinates match detected boxes.
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
        temp_path = tmp.name
    try:
        cv2.imwrite(temp_path, gray)
        config = f"--oem 1 --psm {psm} -c preserve_interword_spaces=1"
        data = pytesseract.image_to_data(
            temp_path,
            lang=lang,
            config=config,
            output_type=pytesseract.Output.DICT,
            timeout=timeout,
        )
    finally:
        try:
            os.unlink(temp_path)
        except OSError:
            pass

    words: list[OCRWord] = []
    confs: list[float] = []
    n = len(data.get("text", []) or [])
    for i in range(n):
        text = str(data.get("text", [])[i] or "").strip()
        if not text:
            continue
        try:
            conf = float(data.get("conf", [])[i])
        except Exception:
            conf = -1.0
        if conf >= 0:
            confs.append(conf)
        try:
            words.append(
                OCRWord(
                    text=text,
                    left=int(data.get("left", [0])[i]),
                    top=int(data.get("top", [0])[i]),
                    width=int(data.get("width", [0])[i]),
                    height=int(data.get("height", [0])[i]),
                    confidence=conf if conf >= 0 else 0.0,
                    block_num=int(data.get("block_num", [0])[i]),
                    par_num=int(data.get("par_num", [0])[i]),
                    line_num=int(data.get("line_num", [0])[i]),
                    word_num=int(data.get("word_num", [0])[i]),
                )
            )
        except Exception:
            continue
    confidence = sum(confs) / len(confs) if confs else 0.0
    page_text = _text_from_data(data)
    return words, confidence, page_text


def words_inside_box_to_text(words: list[OCRWord], bbox: tuple[int, int, int, int], pad: int = 4) -> tuple[str, float]:
    """Convert page-level OCR words inside one voter card box into card text."""
    x, y, w, h = bbox
    x1, y1, x2, y2 = x - pad, y - pad, x + w + pad, y + h + pad
    inside = [wd for wd in words if x1 <= wd.cx <= x2 and y1 <= wd.cy <= y2]
    if not inside:
        return "", 0.0

    # Group words into visual lines. Tesseract line_num is useful but may merge
    # table columns; y-based grouping keeps each card independent.
    inside.sort(key=lambda wd: (wd.top, wd.left))
    heights = sorted([max(1, wd.height) for wd in inside])
    med_h = heights[len(heights) // 2] if heights else 12
    row_tol = max(8, int(med_h * 0.65))
    rows: list[list[OCRWord]] = []
    for wd in inside:
        placed = False
        center_y = wd.cy
        for row in rows:
            row_y = sum(x.cy for x in row) / len(row)
            if abs(center_y - row_y) <= row_tol:
                row.append(wd)
                placed = True
                break
        if not placed:
            rows.append([wd])
    rows.sort(key=lambda row: sum(wd.cy for wd in row) / len(row))
    lines: list[str] = []
    confs: list[float] = []
    for row in rows:
        row.sort(key=lambda wd: wd.left)
        line = " ".join(wd.text for wd in row).strip()
        if line:
            lines.append(line)
        confs.extend([wd.confidence for wd in row if wd.confidence >= 0])
    confidence = sum(confs) / len(confs) if confs else 0.0
    return "\n".join(lines), confidence
