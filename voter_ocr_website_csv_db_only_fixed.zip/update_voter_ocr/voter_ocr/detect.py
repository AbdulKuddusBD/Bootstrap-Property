from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Box:
    x: int
    y: int
    w: int
    h: int

    @property
    def area(self) -> int:
        return self.w * self.h

    def padded(self, pad: int, width: int, height: int) -> "Box":
        x1 = max(0, self.x - pad)
        y1 = max(0, self.y - pad)
        x2 = min(width, self.x + self.w + pad)
        y2 = min(height, self.y + self.h + pad)
        return Box(x1, y1, max(1, x2 - x1), max(1, y2 - y1))


def _iou(a: Box, b: Box) -> float:
    x1 = max(a.x, b.x)
    y1 = max(a.y, b.y)
    x2 = min(a.x + a.w, b.x + b.w)
    y2 = min(a.y + a.h, b.y + b.h)
    inter = max(0, x2 - x1) * max(0, y2 - y1)
    if inter == 0:
        return 0.0
    return inter / float(a.area + b.area - inter)


def sort_boxes_row_major(boxes: list[Box]) -> list[Box]:
    if not boxes:
        return []
    boxes = sorted(boxes, key=lambda b: (b.y, b.x))
    heights = sorted([b.h for b in boxes])
    median_h = heights[len(heights) // 2]
    row_tol = max(12, int(median_h * 0.35))
    rows: list[list[Box]] = []
    for box in boxes:
        placed = False
        for row in rows:
            row_y = sum(b.y for b in row) / len(row)
            if abs(box.y - row_y) <= row_tol:
                row.append(box)
                placed = True
                break
        if not placed:
            rows.append([box])
    rows = sorted(rows, key=lambda row: sum(b.y for b in row) / len(row))
    out: list[Box] = []
    for row in rows:
        out.extend(sorted(row, key=lambda b: b.x))
    return out


def _merge_close(values: list[int], tolerance: int) -> list[int]:
    if not values:
        return []
    values = sorted(values)
    groups: list[list[int]] = [[values[0]]]
    for v in values[1:]:
        if abs(v - groups[-1][-1]) <= tolerance:
            groups[-1].append(v)
        else:
            groups.append([v])
    return [int(round(sum(g) / len(g))) for g in groups]


def _project_line_centers(mask, axis: int, threshold: int, merge_tol: int) -> list[int]:
    """Return line centers from a binary horizontal/vertical mask."""
    import numpy as np

    proj = (mask > 0).sum(axis=axis)
    idx = np.where(proj >= threshold)[0]
    if len(idx) == 0:
        return []
    groups: list[tuple[int, int]] = []
    start = int(idx[0])
    prev = int(idx[0])
    for item in idx[1:]:
        item = int(item)
        if item > prev + 2:
            groups.append((start, prev))
            start = item
        prev = item
    groups.append((start, prev))
    centers = [(a + b) // 2 for a, b in groups]
    return _merge_close(centers, merge_tol)


def _detect_grid_boxes(page_image_path: Path) -> list[Box]:
    """Detect voter-card cells from long border lines.

    The older contour-only method often merged all cards into one large grid,
    which caused empty CSV/DB files. This method reads the long horizontal and
    vertical border line coordinates and creates each table cell directly.
    """
    import cv2

    image = cv2.imread(str(page_image_path))
    if image is None:
        raise RuntimeError(f"Could not read image: {page_image_path}")
    height, width = image.shape[:2]
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    blur = cv2.GaussianBlur(gray, (3, 3), 0)
    th = cv2.adaptiveThreshold(
        blur, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY_INV, 31, 15
    )

    hor_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (max(35, width // 40), 1))
    ver_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, max(35, height // 45)))
    horizontal = cv2.morphologyEx(th, cv2.MORPH_OPEN, hor_kernel, iterations=1)
    vertical = cv2.morphologyEx(th, cv2.MORPH_OPEN, ver_kernel, iterations=1)

    merge_tol = max(10, int(height * 0.008))
    # Horizontal card borders usually span the full 3-column grid (~70% page width).
    y_lines = _project_line_centers(
        horizontal,
        axis=1,
        threshold=max(120, int(width * 0.45)),
        merge_tol=merge_tol,
    )
    # Vertical card borders are long, covering the full voter table height.
    x_lines = _project_line_centers(
        vertical,
        axis=0,
        threshold=max(120, int(height * 0.20)),
        merge_tol=max(10, int(width * 0.006)),
    )

    # Keep only the actual voter grid area; ignore title/header table lines.
    x_lines = [x for x in x_lines if int(width * 0.08) <= x <= int(width * 0.94)]
    y_lines = [y for y in y_lines if int(height * 0.10) <= y <= int(height * 0.92)]

    if len(x_lines) < 4 or len(y_lines) < 2:
        return []

    # If extra header vertical lines are present, keep the widest 3-column group.
    best_x = x_lines
    if len(x_lines) > 4:
        best_score = -1
        best_group = None
        for i in range(0, len(x_lines) - 3):
            group = x_lines[i : i + 4]
            widths = [group[j + 1] - group[j] for j in range(3)]
            if min(widths) <= 0:
                continue
            score = sum(widths) - (max(widths) - min(widths)) * 2
            if score > best_score:
                best_score = score
                best_group = group
        if best_group:
            best_x = best_group
    x_lines = best_x

    boxes: list[Box] = []
    for y1, y2 in zip(y_lines, y_lines[1:]):
        h = y2 - y1
        if not (0.055 * height <= h <= 0.18 * height):
            continue
        for x1, x2 in zip(x_lines, x_lines[1:]):
            w = x2 - x1
            if not (0.18 * width <= w <= 0.33 * width):
                continue
            boxes.append(Box(int(x1), int(y1), int(w), int(h)))

    return sort_boxes_row_major(boxes)


def _detect_contour_boxes(page_image_path: Path) -> list[Box]:
    import cv2

    image = cv2.imread(str(page_image_path))
    if image is None:
        raise RuntimeError(f"Could not read image: {page_image_path}")
    height, width = image.shape[:2]
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    blur = cv2.GaussianBlur(gray, (3, 3), 0)
    th = cv2.adaptiveThreshold(
        blur, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY_INV, 31, 15
    )

    hor_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (max(20, width // 28), 1))
    ver_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, max(20, height // 35)))
    horizontal = cv2.morphologyEx(th, cv2.MORPH_OPEN, hor_kernel, iterations=1)
    vertical = cv2.morphologyEx(th, cv2.MORPH_OPEN, ver_kernel, iterations=1)
    lines = cv2.add(horizontal, vertical)
    close_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
    lines = cv2.morphologyEx(lines, cv2.MORPH_CLOSE, close_kernel, iterations=2)

    contours, _ = cv2.findContours(lines, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    candidates: list[Box] = []
    for cnt in contours:
        x, y, w, h = cv2.boundingRect(cnt)
        area = w * h
        if area <= 0:
            continue
        if not (0.18 * width <= w <= 0.36 * width):
            continue
        if not (0.055 * height <= h <= 0.18 * height):
            continue
        if y < 0.20 * height:
            continue
        if area < 0.010 * width * height:
            continue
        candidates.append(Box(int(x), int(y), int(w), int(h)))

    candidates = sorted(candidates, key=lambda b: b.area, reverse=True)
    filtered: list[Box] = []
    for box in candidates:
        if all(_iou(box, old) < 0.45 for old in filtered):
            filtered.append(box)
    return sort_boxes_row_major(filtered)


def detect_voter_boxes(page_image_path: Path) -> list[Box]:
    """Detect rectangular voter cards from a rendered voter-list page."""
    try:
        import cv2  # noqa: F401
        import numpy as np  # noqa: F401
    except Exception as exc:  # pragma: no cover
        raise RuntimeError("OpenCV missing. Run: pip install -r requirements.txt") from exc

    grid_boxes = _detect_grid_boxes(page_image_path)
    if len(grid_boxes) >= 3:
        return grid_boxes
    return _detect_contour_boxes(page_image_path)


def fallback_grid_boxes(page_image_path: Path, rows: int = 5, cols: int = 3) -> list[Box]:
    """Fallback crop grid for pages where line detection fails.

    This is used only when border detection fails completely. It tries to match
    the common Bangladesh EC layout: 3 columns and 5 voter-card rows.
    """
    try:
        import cv2
    except Exception as exc:  # pragma: no cover
        raise RuntimeError("OpenCV missing. Run: pip install -r requirements.txt") from exc

    image = cv2.imread(str(page_image_path))
    if image is None:
        raise RuntimeError(f"Could not read image: {page_image_path}")
    height, width = image.shape[:2]

    left = int(width * 0.137)
    right = int(width * 0.862)
    top = int(height * 0.232)
    bottom = int(height * 0.815)
    gap_x = 0
    gap_y = 0
    cell_w = (right - left - gap_x * (cols - 1)) // cols
    cell_h = (bottom - top - gap_y * (rows - 1)) // rows

    boxes: list[Box] = []
    for r in range(rows):
        for c in range(cols):
            x = left + c * (cell_w + gap_x)
            y = top + r * (cell_h + gap_y)
            boxes.append(Box(x, y, cell_w, cell_h))
    return boxes


def crop_box(page_image_path: Path, box: Box, out_path: Path, pad: int = 8) -> Path:
    import cv2

    image = cv2.imread(str(page_image_path))
    if image is None:
        raise RuntimeError(f"Could not read image: {page_image_path}")
    height, width = image.shape[:2]
    box = box.padded(pad, width, height)
    crop = image[box.y : box.y + box.h, box.x : box.x + box.w]
    out_path.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(out_path), crop)
    return out_path
