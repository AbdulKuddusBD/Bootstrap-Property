#!/usr/bin/env bash
set -e
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
if command -v apt >/dev/null 2>&1; then
  sudo apt update
  sudo apt install -y tesseract-ocr tesseract-ocr-ben
fi
echo "Setup complete. Run: source .venv/bin/activate"
