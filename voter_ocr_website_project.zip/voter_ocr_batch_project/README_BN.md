# Voter OCR Batch Website + CLI

এই প্রজেক্টটি মূলত একটি **লোকাল ওয়েবসাইট**। ওয়েবসাইটে ZIP ফাইল upload করবেন, ZIP-এর ভিতরে যত folder/PDF থাকবে সব automatic process হবে। Processing শেষ হলে website থেকেই output ZIP download করবেন।

Input ZIP-এর folder structure বজায় থাকবে, কিন্তু output ZIP-এ original PDF copy করা হবে না। প্রতিটি PDF-এর জন্য CSV + SQLite DB + debug CSV + needs-review CSV + review HTML + crop images তৈরি হবে। Per-PDF output filename ডিফল্টভাবে PDF-এর ভিতরের **ভোটার এলাকার নম্বর/কোড** থেকে হবে। যেমন ভোটার এলাকার নম্বর `২৬৩০` হলে output হবে `2630.csv`, `2630.db`, `2630_review.html`। Root folder-এ combined `all_records.csv` এবং `all_records.db` থাকবে।

---

## ১) ওয়েবসাইট চালানোর নিয়ম

### Linux/Ubuntu

```bash
cd voter_ocr_batch_project
bash setup_linux.sh
source .venv/bin/activate
python web_app.py
```

### Windows

প্রথমে Python 3.10+ এবং Tesseract OCR install করুন। তারপর project folder-এ:

```bat
pip install -r requirements.txt
python web_app.py
```

অথবা `run_web.bat` double click করতে পারেন।

### Browser link

ওয়েবসাইট চালু হলে browser-এ খুলুন:

```text
http://127.0.0.1:8000
```

তারপর:

1. ZIP file select করুন।
2. DPI 400 রাখুন।
3. Save Crops = `all` রাখলে manual review সবচেয়ে ভালো হবে।
4. `Upload & Process ZIP` চাপুন।
5. Processing page খোলা রাখুন।
6. কাজ শেষ হলে `Download Output ZIP` button আসবে।

---

## ২) Website-এর ভিতরে কী আছে

Website-এ আছে:

- ZIP upload form
- DPI setting
- OCR confidence setting
- crop image রাখবেন কি না setting
- output filename ভোটার এলাকার নম্বর/কোড থেকে হবে কি না setting
- background processing page
- processing শেষ হলে download button
- error হলে error details page

---

## ৩) Output fields

Main CSV-তে এই ৮টি field থাকবে:

1. ক্রমিক নং
2. ভোটার নং
3. নাম
4. পিতা
5. মাতা
6. পেশা
7. জন্ম তারিখ
8. ঠিকানা

Debug CSV-তে এগুলোর সাথে voter area number, source PDF, source folder, output basename, page/card number, crop image, OCR confidence, needs_review, review notes এবং raw OCR text থাকবে।

---

## ৪) Output filename

ডিফল্টভাবে প্রতিটি PDF-এর output file নাম হবে PDF-এর ভিতরে থাকা **ভোটার এলাকার নম্বর/কোড** থেকে।

উদাহরণ:

```text
ভোটার এলাকার নম্বর: ২৬৩০
```

Output:

```text
2630.csv
2630.db
2630_debug.csv
2630_needs_review.csv
2630_review.html
2630_crops/
```

দুইটি PDF একই folder-এ একই ভোটার এলাকার নম্বর হলে overwrite হবে না; দ্বিতীয়টির নাম হবে:

```text
2630__2.csv
2630__2.db
```

যদি OCR ভোটার এলাকার নম্বর detect করতে না পারে, তাহলে fallback হিসেবে original PDF filename ব্যবহার করবে।

---

## ৫) Output structure example

Input ZIP:

```text
data.zip
├── 612390/a.pdf
├── 612390/b.pdf
└── 612460/c.pdf
```

Output ZIP:

```text
output.zip
├── all_records.csv
├── all_records_debug.csv
├── all_needs_review.csv
├── all_records.db
├── summary.json
├── 612390/
│   ├── 2362.csv
│   ├── 2362_debug.csv
│   ├── 2362_needs_review.csv
│   ├── 2362.db
│   ├── 2362_review.html
│   └── 2362_crops/
└── 612460/
    ├── 625.csv
    ├── 625.db
    └── 625_review.html
```

---

## ৬) 100% accuracy workflow

OCR নিজে থেকে 100% guarantee করতে পারে না। তাই final 100% accurate database করার জন্য এই project-এ review system রাখা হয়েছে।

Recommended flow:

1. Website থেকে ZIP upload করে output ZIP download করুন।
2. Output unzip করুন।
3. `*_review.html` খুলুন।
4. crop image দেখে doubtful records ঠিক করুন।
5. `*_needs_review.csv` আগে চেক করুন।
6. corrected CSV থেকে DB rebuild করতে:

```bash
python tools/rebuild_db_from_csv.py corrected.csv corrected.db
```

---

## ৭) CLI ব্যবহার করতে চাইলে

Website ছাড়াও command line দিয়ে চালানো যাবে:

```bash
python main.py --input data.zip --output output.zip --dpi 400 --save-crops all
```

বাংলা digit দিয়ে filename রাখতে চাইলে:

```bash
python main.py --input data.zip --output output.zip --filename-digits original
```

Original PDF filename ব্যবহার করতে চাইলে:

```bash
python main.py --input data.zip --output output.zip --filename-mode original_pdf
```

---

## ৮) Install dependency

### Linux

```bash
sudo apt update
sudo apt install -y tesseract-ocr tesseract-ocr-ben
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### Windows

1. Python 3.10+ install করুন।
2. Tesseract OCR install করুন।
3. Bengali language data `ben.traineddata` install আছে কিনা দেখুন।
4. Project folder-এ:

```bat
pip install -r requirements.txt
```

Tesseract Windows-এ PATH-এ না থাকলে সাধারণ path:

```text
C:\Program Files\Tesseract-OCR\tesseract.exe
```

---

## ৯) Troubleshooting

### Website খুলছে না

Terminal-এ নিশ্চিত করুন:

```bash
python web_app.py
```

তারপর browser-এ:

```text
http://127.0.0.1:8000
```

### Bangla OCR language missing

```bash
tesseract --list-langs
```

এখানে `ben` থাকতে হবে।

### pdftoppm error

এই project `pdftoppm` ব্যবহার করে না। PDF render করার জন্য PyMuPDF ব্যবহার করা হয়েছে। তাই poppler dependency নেই।

### Output ভুল হলে

- DPI 400 বা 450 করে চালান।
- Save Crops = `all` রাখুন।
- `all_needs_review.csv` আগে ঠিক করুন।
- crop image দেখে suspicious record correct করুন।

---

## Notes

- Project local/offline চলে।
- কোনো paid OCR API লাগে না।
- Unlimited processing possible, শুধু আপনার computer/server speed ও storage অনুযায়ী সময় লাগবে।
- Output ZIP-এ original PDF রাখা হয় না।
