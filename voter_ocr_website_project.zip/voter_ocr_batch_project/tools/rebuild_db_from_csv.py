from __future__ import annotations

import argparse
import csv
from pathlib import Path

from voter_ocr.processor import DEBUG_CSV_FIELDS, MAIN_CSV_FIELDS
from voter_ocr.utils import init_db, insert_records


def read_csv(path: Path) -> list[dict]:
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def main() -> None:
    parser = argparse.ArgumentParser(description="Rebuild SQLite DB from a corrected voter CSV file.")
    parser.add_argument("csv", help="Corrected CSV path")
    parser.add_argument("db", help="Output DB path")
    args = parser.parse_args()
    rows = read_csv(Path(args.csv))
    conn = init_db(Path(args.db))
    insert_records(conn, rows)
    conn.close()
    print(f"Done: {args.db} ({len(rows)} records)")


if __name__ == "__main__":
    main()
