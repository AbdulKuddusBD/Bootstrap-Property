@echo off
REM Usage: run_cli.bat input.zip output.zip
python -m pip install -r requirements.txt
python main.py --input %1 --output %2 --dpi 400 --save-crops all
pause
