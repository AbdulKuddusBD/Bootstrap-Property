from __future__ import annotations

import json
import tempfile
import threading
import time
import traceback
import uuid
from dataclasses import asdict
from pathlib import Path
from typing import Any

from flask import Flask, jsonify, redirect, request, send_file, url_for
from werkzeug.utils import secure_filename

from voter_ocr.processor import ProcessConfig, process_zip

app = Flask(__name__)

# All web jobs are stored locally. Original uploaded PDFs are not copied into the
# final output ZIP; they stay only in this temporary job folder while processing.
BASE_DIR = Path(__file__).resolve().parent
JOB_ROOT = BASE_DIR / "web_jobs"
JOB_ROOT.mkdir(exist_ok=True)

JOBS: dict[str, dict[str, Any]] = {}
JOBS_LOCK = threading.Lock()


def _html_page(title: str, body: str) -> str:
    return f"""
<!doctype html>
<html lang="bn">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<style>
:root {{
  --bg:#f2f5fb; --card:#ffffff; --text:#111827; --muted:#6b7280; --line:#d9e0ea;
  --primary:#0f172a; --accent:#2563eb; --good:#047857; --bad:#b91c1c; --warn:#b45309;
}}
* {{ box-sizing:border-box; }}
body {{ margin:0; background:linear-gradient(135deg,#edf4ff,#f8fafc 45%,#eef2ff); color:var(--text); font-family:system-ui,-apple-system,"Segoe UI",Arial,"Noto Sans Bengali",sans-serif; }}
.wrap {{ max-width:1040px; margin:0 auto; padding:28px 16px 50px; }}
.hero {{ display:grid; grid-template-columns:1.2fr .8fr; gap:18px; align-items:stretch; margin-bottom:18px; }}
.card {{ background:rgba(255,255,255,.92); border:1px solid var(--line); border-radius:22px; box-shadow:0 12px 40px rgba(15,23,42,.08); padding:24px; }}
h1 {{ font-size:34px; line-height:1.2; margin:0 0 10px; letter-spacing:-.02em; }}
h2 {{ margin:0 0 12px; font-size:21px; }}
p {{ color:var(--muted); line-height:1.7; margin:8px 0; }}
.badge {{ display:inline-flex; align-items:center; gap:6px; background:#e0ecff; color:#1d4ed8; padding:7px 11px; border-radius:999px; font-weight:700; font-size:13px; margin-bottom:12px; }}
.grid {{ display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:14px; }}
label {{ display:block; font-weight:700; margin:14px 0 7px; }}
input,select,button {{ width:100%; border:1px solid var(--line); border-radius:14px; padding:12px 13px; font-size:16px; background:#fff; }}
input[type=file] {{ padding:16px; border:2px dashed #9db5d8; background:#f8fbff; }}
button,.btn {{ display:inline-flex; align-items:center; justify-content:center; text-decoration:none; cursor:pointer; border:0; background:var(--primary); color:white; font-weight:800; border-radius:14px; padding:14px 18px; margin-top:18px; }}
.btn.secondary {{ background:#e5e7eb; color:#111827; }}
.small {{ font-size:13px; color:var(--muted); }}
.note {{ background:#fff7ed; border:1px solid #fed7aa; color:#9a3412; padding:12px 14px; border-radius:15px; margin:12px 0; line-height:1.7; }}
.ok {{ background:#ecfdf5; border:1px solid #a7f3d0; color:#065f46; }}
.err {{ background:#fef2f2; border:1px solid #fecaca; color:#991b1b; }}
.steps {{ display:grid; gap:10px; margin-top:10px; }}
.step {{ padding:12px; border-radius:14px; background:#f8fafc; border:1px solid var(--line); font-weight:650; }}
.progressbar {{ width:100%; height:16px; background:#e5e7eb; border-radius:999px; overflow:hidden; margin:14px 0; }}
.progressbar > div {{ width:30%; height:100%; background:linear-gradient(90deg,#2563eb,#60a5fa); border-radius:999px; animation:move 1.2s infinite ease-in-out; }}
@keyframes move {{ 0%{{transform:translateX(-100%)}} 50%{{transform:translateX(160%)}} 100%{{transform:translateX(360%)}} }}
pre {{ white-space:pre-wrap; background:#0f172a; color:#e5e7eb; padding:14px; border-radius:14px; overflow:auto; }}
.table {{ width:100%; border-collapse:collapse; margin-top:12px; }}
.table th,.table td {{ text-align:left; padding:10px; border-bottom:1px solid var(--line); }}
.table th {{ color:#374151; background:#f8fafc; }}
@media (max-width:800px) {{ .hero,.grid {{ grid-template-columns:1fr; }} h1{{font-size:28px;}} }}
</style>
</head>
<body><div class="wrap">{body}</div></body>
</html>
"""


INDEX_BODY = """
<div class="hero">
  <section class="card">
    <div class="badge">Local Free OCR Website</div>
    <h1>ভোটার PDF OCR Batch Processor</h1>
    <p>এখানে আপনার ZIP ফাইল upload করুন। ZIP-এর ভিতরে যত folder/PDF থাকবে সব automatic process হবে। Output ZIP-এ original PDF রাখা হবে না; একই folder structure অনুযায়ী CSV, DB, review HTML এবং crop image তৈরি হবে।</p>
    <div class="note ok">প্রতি PDF-এর output filename ডিফল্টভাবে PDF-এর ভিতরের ভোটার এলাকার নম্বর/কোড থেকে হবে। যেমন ২৬৩০ হলে output হবে 2630.csv, 2630.db।</div>
  </section>
  <aside class="card">
    <h2>Output পাবেন</h2>
    <div class="steps">
      <div class="step">প্রতিটি PDF → ভোটার_এলাকা_নম্বর.csv</div>
      <div class="step">প্রতিটি PDF → ভোটার_এলাকা_নম্বর.db</div>
      <div class="step">Review HTML + crop images</div>
      <div class="step">Root এ all_records.csv + all_records.db</div>
    </div>
  </aside>
</div>

<form class="card" method="post" action="/jobs" enctype="multipart/form-data">
  <h2>ZIP Upload</h2>
  <p>ZIP-এর ভিতরে subfolder থাকলেও সমস্যা নেই। শুধু PDF ফাইলগুলো process হবে।</p>

  <label>ZIP File</label>
  <input type="file" name="zipfile" accept=".zip,application/zip,application/x-zip-compressed" required>

  <div class="grid">
    <div>
      <label>DPI</label>
      <input type="number" name="dpi" value="400" min="200" max="600">
      <div class="small">ভালো accuracy এর জন্য 400 recommended।</div>
    </div>
    <div>
      <label>Minimum OCR Confidence</label>
      <input type="number" name="min_confidence" value="70" min="0" max="100">
      <div class="small">এর নিচে হলে record review-needed হবে।</div>
    </div>
  </div>

  <div class="grid">
    <div>
      <label>Save Crops</label>
      <select name="save_crops">
        <option value="all" selected>all - সব crop image রাখবে, manual review সহজ</option>
        <option value="flagged">flagged - শুধু সন্দেহজনক records এর crop রাখবে</option>
        <option value="none">none - crop রাখবে না, output ছোট</option>
      </select>
    </div>
    <div>
      <label>Filename Digits</label>
      <select name="filename_digits">
        <option value="english" selected>English digits: 2630.csv</option>
        <option value="original">Original/Bangla digits: ২৬৩০.csv</option>
      </select>
    </div>
  </div>

  <label>Output filename mode</label>
  <select name="filename_mode">
    <option value="voter_area" selected>ভোটার এলাকার নম্বর/কোড থেকে filename</option>
    <option value="original_pdf">Original PDF filename থেকে filename</option>
  </select>

  <button type="submit">Upload & Process ZIP</button>
  <div class="note">বড় ZIP হলে browser page খোলা রাখুন। Processing শেষ হলে Download button আসবে। OCR নিজে 100% guarantee করে না, তাই final output ঠিক করার জন্য review file দেওয়া হয়।</div>
</form>
"""


JOB_BODY = """
<section class="card">
  <div class="badge">Processing Job</div>
  <h1>ZIP Processing চলছে</h1>
  <p id="statusText">Status দেখার জন্য অপেক্ষা করুন...</p>
  <div id="progress" class="progressbar"><div></div></div>
  <div id="message" class="note">Upload হয়ে গেছে। এখন background এ OCR চলছে।</div>
  <div id="downloadArea"></div>
  <div id="summaryArea"></div>
  <p class="small">Job ID: <span id="jobId"></span></p>
</section>
<script>
const jobId = location.pathname.split('/').pop();
document.getElementById('jobId').textContent = jobId;
function renderSummary(summary) {
  if (!summary) return '';
  const rows = [];
  if (summary.total_pdfs !== undefined) rows.push(['Total PDFs', summary.total_pdfs]);
  if (summary.total_records !== undefined) rows.push(['Total records', summary.total_records]);
  if (summary.total_needs_review !== undefined) rows.push(['Needs review', summary.total_needs_review]);
  if (summary.output_zip !== undefined) rows.push(['Output ZIP', summary.output_zip]);
  if (!rows.length) return '<pre>'+escapeHtml(JSON.stringify(summary,null,2))+'</pre>';
  return '<table class="table"><tbody>'+rows.map(r=>`<tr><th>${escapeHtml(r[0])}</th><td>${escapeHtml(String(r[1]))}</td></tr>`).join('')+'</tbody></table>';
}
function escapeHtml(s){return s.replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
async function poll(){
  try {
    const res = await fetch('/api/jobs/'+jobId, {cache:'no-store'});
    const data = await res.json();
    document.getElementById('statusText').textContent = 'Status: ' + data.status;
    if (data.status === 'done') {
      document.getElementById('progress').style.display = 'none';
      document.getElementById('message').className = 'note ok';
      document.getElementById('message').textContent = 'Processing complete. এখন output ZIP download করুন।';
      document.getElementById('downloadArea').innerHTML = '<a class="btn" href="/download/'+jobId+'">Download Output ZIP</a> <a class="btn secondary" href="/">আরেকটা ZIP Upload করুন</a>';
      document.getElementById('summaryArea').innerHTML = renderSummary(data.summary);
      return;
    }
    if (data.status === 'error') {
      document.getElementById('progress').style.display = 'none';
      document.getElementById('message').className = 'note err';
      document.getElementById('message').textContent = 'Processing failed. নিচের error দেখুন।';
      document.getElementById('summaryArea').innerHTML = '<pre>'+escapeHtml(data.error || 'Unknown error')+'</pre><a class="btn secondary" href="/">Back</a>';
      return;
    }
    document.getElementById('message').textContent = data.message || 'OCR চলছে...';
  } catch(e) {
    document.getElementById('message').className = 'note err';
    document.getElementById('message').textContent = 'Status load করা যায়নি: ' + e;
  }
  setTimeout(poll, 2000);
}
poll();
</script>
"""


def _set_job(job_id: str, **updates: Any) -> None:
    with JOBS_LOCK:
        if job_id not in JOBS:
            JOBS[job_id] = {}
        JOBS[job_id].update(updates)


def _get_job(job_id: str) -> dict[str, Any] | None:
    with JOBS_LOCK:
        job = JOBS.get(job_id)
        return dict(job) if job else None


def _run_job(job_id: str, input_zip: Path, output_zip: Path, config: ProcessConfig) -> None:
    _set_job(job_id, status="running", message="PDF render, box detection এবং OCR চলছে...", started_at=time.time())
    try:
        summary = process_zip(input_zip, output_zip, config=config)
        # Keep summary JSON-safe and small enough for the status API.
        summary_safe = json.loads(json.dumps(summary, ensure_ascii=False, default=str))
        _set_job(
            job_id,
            status="done",
            message="Processing complete",
            finished_at=time.time(),
            summary=summary_safe,
            output_zip=str(output_zip),
        )
    except Exception:
        _set_job(job_id, status="error", message="Processing failed", error=traceback.format_exc(), finished_at=time.time())


@app.get("/")
def index() -> str:
    return _html_page("Voter OCR Batch Website", INDEX_BODY)


@app.post("/jobs")
def create_job():
    file = request.files.get("zipfile")
    if not file or not file.filename:
        return _html_page("Upload error", '<section class="card"><div class="note err">ZIP file পাওয়া যায়নি।</div><a class="btn secondary" href="/">Back</a></section>'), 400

    original_name = secure_filename(file.filename)
    if not original_name.lower().endswith(".zip"):
        return _html_page("Upload error", '<section class="card"><div class="note err">শুধু .zip file upload করুন।</div><a class="btn secondary" href="/">Back</a></section>'), 400

    def int_form(name: str, default: int, low: int, high: int) -> int:
        try:
            value = int(request.form.get(name, str(default)))
        except ValueError:
            value = default
        return max(low, min(high, value))

    def float_form(name: str, default: float, low: float, high: float) -> float:
        try:
            value = float(request.form.get(name, str(default)))
        except ValueError:
            value = default
        return max(low, min(high, value))

    dpi = int_form("dpi", 400, 200, 600)
    min_confidence = float_form("min_confidence", 70.0, 0.0, 100.0)
    save_crops = request.form.get("save_crops", "all")
    if save_crops not in {"all", "flagged", "none"}:
        save_crops = "all"
    filename_mode = request.form.get("filename_mode", "voter_area")
    if filename_mode not in {"voter_area", "original_pdf"}:
        filename_mode = "voter_area"
    filename_digits = request.form.get("filename_digits", "english")
    if filename_digits not in {"english", "original"}:
        filename_digits = "english"

    job_id = uuid.uuid4().hex[:12]
    job_dir = JOB_ROOT / job_id
    job_dir.mkdir(parents=True, exist_ok=True)
    input_zip = job_dir / "input.zip"
    output_zip = job_dir / f"voter_ocr_output_{job_id}.zip"
    file.save(input_zip)

    config = ProcessConfig(
        dpi=dpi,
        min_confidence=min_confidence,
        save_crops=save_crops,  # type: ignore[arg-type]
        filename_mode=filename_mode,  # type: ignore[arg-type]
        filename_digits=filename_digits,  # type: ignore[arg-type]
    )
    _set_job(
        job_id,
        status="queued",
        message="Job queue করা হয়েছে...",
        original_name=original_name,
        input_zip=str(input_zip),
        output_zip=str(output_zip),
        config=asdict(config),
        created_at=time.time(),
    )
    thread = threading.Thread(target=_run_job, args=(job_id, input_zip, output_zip, config), daemon=True)
    thread.start()
    return redirect(url_for("job_page", job_id=job_id))


# Backward-compatible endpoint: old form action /process also works.
@app.post("/process")
def process_upload_compat():
    return create_job()


@app.get("/jobs/<job_id>")
def job_page(job_id: str) -> str:
    if not _get_job(job_id):
        return _html_page("Job not found", '<section class="card"><div class="note err">এই Job ID পাওয়া যায়নি।</div><a class="btn secondary" href="/">Back</a></section>'), 404
    return _html_page("Processing", JOB_BODY)


@app.get("/api/jobs/<job_id>")
def job_status(job_id: str):
    job = _get_job(job_id)
    if not job:
        return jsonify({"status": "not_found", "error": "Job not found"}), 404
    public_job = {k: v for k, v in job.items() if k not in {"input_zip", "output_zip"}}
    return jsonify(public_job)


@app.get("/download/<job_id>")
def download(job_id: str):
    job = _get_job(job_id)
    if not job or job.get("status") != "done":
        return _html_page("Download error", '<section class="card"><div class="note err">Output ZIP এখনো ready না।</div><a class="btn secondary" href="/">Back</a></section>'), 404
    output_zip = Path(job.get("output_zip", ""))
    if not output_zip.exists():
        return _html_page("Download error", '<section class="card"><div class="note err">Output ZIP file পাওয়া যায়নি।</div><a class="btn secondary" href="/">Back</a></section>'), 404
    return send_file(output_zip, as_attachment=True, download_name=output_zip.name)


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8000, debug=False, threaded=True)
