from __future__ import annotations

import os
import re
import tempfile
from dataclasses import dataclass
from pathlib import Path


@dataclass
class OCRResult:
    text: str
    confidence: float
    labels_found: int
    variant_name: str


LABELS = ["নাম", "ভোটার", "পিতা", "মাতা", "পেশা", "জন্ম", "ঠিকানা"]


def check_tesseract(lang: str = "ben+eng") -> tuple[bool, str]:
    try:
        import pytesseract
        version = pytesseract.get_tesseract_version()
        langs = set(pytesseract.get_languages(config=""))
        missing = []
        for item in lang.split("+"):
            if item and item not in langs:
                missing.append(item)
        if missing:
            return False, f"Tesseract found ({version}), but missing language data: {', '.join(missing)}"
        return True, f"Tesseract ready ({version}), languages OK: {lang}"
    except Exception as exc:
        return False, f"Tesseract/PyTesseract not ready: {exc}"


def _preprocess_variants(image_path: Path) -> list[tuple[str, object]]:
    import cv2

    image = cv2.imread(str(image_path))
    if image is None:
        raise RuntimeError(f"Could not read image: {image_path}")
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    variants: list[tuple[str, object]] = []

    # 1. Upscaled grayscale keeps glyph shapes.
    up = cv2.resize(gray, None, fx=2.0, fy=2.0, interpolation=cv2.INTER_CUBIC)
    variants.append(("gray_2x", up))

    # 2. Adaptive threshold helps faint scans.
    ad = cv2.adaptiveThreshold(up, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 35, 11)
    variants.append(("adaptive_2x", ad))

    # 3. Otsu threshold after mild blur helps noisy scans.
    blur = cv2.GaussianBlur(up, (3, 3), 0)
    _, otsu = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    variants.append(("otsu_2x", otsu))

    # 4. Slightly larger text for tiny boxes.
    up3 = cv2.resize(gray, None, fx=3.0, fy=3.0, interpolation=cv2.INTER_CUBIC)
    variants.append(("gray_3x", up3))

    return variants


def _ocr_image_array(image, lang: str, psm: int) -> OCRResult:
    import cv2
    import pytesseract

    config = f"--oem 1 --psm {psm} -c preserve_interword_spaces=1"
    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
        temp_path = tmp.name
    try:
        cv2.imwrite(temp_path, image)
        text = pytesseract.image_to_string(temp_path, lang=lang, config=config)
        data = pytesseract.image_to_data(temp_path, lang=lang, config=config, output_type=pytesseract.Output.DICT)
        confs = []
        for c in data.get("conf", []):
            try:
                val = float(c)
                if val >= 0:
                    confs.append(val)
            except Exception:
                pass
        confidence = sum(confs) / len(confs) if confs else 0.0
        labels_found = sum(1 for label in LABELS if label in text)
        # Bonus labels matter more than raw confidence for structured cards.
        return OCRResult(text=text, confidence=confidence, labels_found=labels_found, variant_name="")
    finally:
        try:
            os.unlink(temp_path)
        except OSError:
            pass


def run_ocr(image_path: Path, lang: str = "ben+eng") -> OCRResult:
    """Run Bengali OCR using multiple preprocessing variants and choose the best."""
    try:
        import pytesseract  # noqa: F401
    except Exception as exc:  # pragma: no cover
        raise RuntimeError("pytesseract missing. Run: pip install -r requirements.txt") from exc

    best: OCRResult | None = None
    for name, img in _preprocess_variants(image_path):
        for psm in (6, 4):
            result = _ocr_image_array(img, lang=lang, psm=psm)
            result.variant_name = f"{name}_psm{psm}"
            text_len = len(re.sub(r"\s+", "", result.text))
            score = result.labels_found * 1000 + result.confidence * 10 + min(text_len, 250)
            if best is None:
                best = result
                best_score = score
            elif score > best_score:  # type: ignore[name-defined]
                best = result
                best_score = score
    return best or OCRResult("", 0.0, 0, "none")
