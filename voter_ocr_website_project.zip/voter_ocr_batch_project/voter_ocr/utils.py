from __future__ import annotations

import csv
import os
import re
import shutil
import sqlite3
import zipfile
from pathlib import Path
from typing import Iterable, Sequence

BN_TO_EN = str.maketrans("০১২৩৪৫৬৭৮৯", "0123456789")
EN_TO_BN = str.maketrans("0123456789", "০১২৩৪৫৬৭৮৯")


def bn_to_en_digits(value: str | None) -> str:
    return (value or "").translate(BN_TO_EN)


def en_to_bn_digits(value: str | None) -> str:
    return (value or "").translate(EN_TO_BN)


def clean_cell(value: str | None) -> str:
    if not value:
        return ""
    value = value.replace("\u200c", "").replace("\ufeff", "")
    value = re.sub(r"[\t\r]+", " ", value)
    value = re.sub(r" {2,}", " ", value)
    value = re.sub(r"\s*:\s*", ": ", value)
    return value.strip(" \n:-।|")


def safe_filename_base(value: str | None, fallback: str = "file") -> str:
    """Return a filesystem-safe base name without extension.

    Bangla characters are kept, but slashes and OS-reserved characters are replaced.
    """
    name = (value or "").strip() or fallback
    name = re.sub(r"[\\/:*?\"<>|]+", "_", name)
    name = re.sub(r"\s+", "_", name)
    name = name.strip("._- ") or fallback
    return name[:140]


def safe_stem(path: Path) -> str:
    return safe_filename_base(path.stem, fallback="file")


def ensure_empty_dir(path: Path) -> None:
    if path.exists():
        shutil.rmtree(path)
    path.mkdir(parents=True, exist_ok=True)


def find_pdfs(root: Path) -> list[Path]:
    return sorted([p for p in root.rglob("*.pdf") if p.is_file()], key=lambda p: str(p).lower())


def extract_zip(zip_path: Path, dest_dir: Path) -> None:
    with zipfile.ZipFile(zip_path, "r") as zf:
        for member in zf.infolist():
            # ZipSlip protection
            target = dest_dir / member.filename
            target_resolved = target.resolve()
            if not str(target_resolved).startswith(str(dest_dir.resolve())):
                raise RuntimeError(f"Unsafe zip member path: {member.filename}")
            if member.is_dir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(member) as src, open(target, "wb") as dst:
                    shutil.copyfileobj(src, dst)


def make_zip(src_dir: Path, zip_path: Path) -> None:
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for file in sorted(src_dir.rglob("*")):
            if file.is_file():
                zf.write(file, file.relative_to(src_dir).as_posix())


def write_csv(path: Path, records: Sequence[dict], fields: Sequence[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for r in records:
            writer.writerow({k: r.get(k, "") for k in fields})


def init_db(path: Path) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS voters (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            serial_no TEXT,
            voter_no TEXT,
            name TEXT,
            father TEXT,
            mother TEXT,
            occupation TEXT,
            birth_date TEXT,
            address TEXT,
            source_pdf TEXT,
            source_folder TEXT,
            page_no INTEGER,
            card_no INTEGER,
            crop_image TEXT,
            ocr_confidence REAL,
            needs_review INTEGER,
            review_notes TEXT,
            raw_text TEXT,
            voter_area_no TEXT,
            voter_area_no_en TEXT,
            output_basename TEXT,
            voter_no_en TEXT,
            birth_date_en TEXT,
            serial_no_en TEXT
        )
        """
    )
    conn.execute("CREATE INDEX IF NOT EXISTS idx_voter_no ON voters(voter_no)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_voter_no_en ON voters(voter_no_en)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_name ON voters(name)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_father ON voters(father)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_mother ON voters(mother)")
    return conn


def insert_records(conn: sqlite3.Connection, records: Iterable[dict]) -> None:
    rows = []
    for r in records:
        rows.append(
            (
                r.get("ক্রমিক নং", ""),
                r.get("ভোটার নং", ""),
                r.get("নাম", ""),
                r.get("পিতা", ""),
                r.get("মাতা", ""),
                r.get("পেশা", ""),
                r.get("জন্ম তারিখ", ""),
                r.get("ঠিকানা", ""),
                r.get("source_pdf", ""),
                r.get("source_folder", ""),
                int(r.get("page_no", 0) or 0),
                int(r.get("card_no", 0) or 0),
                r.get("crop_image", ""),
                float(r.get("ocr_confidence", 0) or 0),
                1 if r.get("needs_review") in (1, "1", True, "yes", "YES") else 0,
                r.get("review_notes", ""),
                r.get("raw_text", ""),
                r.get("ভোটার এলাকার নম্বর", ""),
                bn_to_en_digits(r.get("ভোটার এলাকার নম্বর", "")),
                r.get("output_basename", ""),
                bn_to_en_digits(r.get("ভোটার নং", "")),
                bn_to_en_digits(r.get("জন্ম তারিখ", "")),
                bn_to_en_digits(r.get("ক্রমিক নং", "")),
            )
        )
    conn.executemany(
        """
        INSERT INTO voters (
            serial_no, voter_no, name, father, mother, occupation, birth_date, address,
            source_pdf, source_folder, page_no, card_no, crop_image, ocr_confidence,
            needs_review, review_notes, raw_text, voter_area_no, voter_area_no_en, output_basename,
            voter_no_en, birth_date_en, serial_no_en
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        rows,
    )
    conn.commit()
