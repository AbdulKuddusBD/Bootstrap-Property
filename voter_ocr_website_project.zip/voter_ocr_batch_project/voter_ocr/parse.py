from __future__ import annotations

import re
from dataclasses import dataclass

from .utils import bn_to_en_digits, clean_cell

FIELD_NAMES = [
    "ক্রমিক নং",
    "ভোটার নং",
    "নাম",
    "পিতা",
    "মাতা",
    "পেশা",
    "জন্ম তারিখ",
    "ঠিকানা",
]


@dataclass
class ParseResult:
    fields: dict
    needs_review: bool
    review_notes: str


def normalize_text(text: str) -> str:
    text = text or ""
    replacements = {
        "：": ":",
        "꞉": ":",
        "।": ".",
        "|": " ",
        "নংঃ": "নং:",
        "নং :": "নং:",
        "তাং": "তারিখ",
        "তারিখঃ": "তারিখ:",
        "ভােটার": "ভোটার",
        "ভােটার নং": "ভোটার নং",
        "মোঃঃ": "মোঃ",
        "মোঃ": "মোঃ",
        "পিতাঃ": "পিতা:",
        "মাতাঃ": "মাতা:",
        "পেশাঃ": "পেশা:",
        "ঠিকানাঃ": "ঠিকানা:",
        "নামঃ": "নাম:",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{2,}", "\n", text)
    return text.strip()


def _line_after_label(line: str, label_regex: str) -> str:
    m = re.search(label_regex + r"\s*[:\-]?\s*(.*)$", line)
    if not m:
        return ""
    return clean_cell(m.group(1))


def _before_any(value: str, markers: list[str]) -> str:
    if not value:
        return ""
    positions = [value.find(m) for m in markers if value.find(m) >= 0]
    if positions:
        value = value[: min(positions)]
    return clean_cell(value)


def parse_card_text(raw_text: str, min_confidence: float = 70, confidence: float = 0.0) -> ParseResult:
    text = normalize_text(raw_text)
    fields = {k: "" for k in FIELD_NAMES}
    notes: list[str] = []

    lines = [clean_cell(x) for x in text.splitlines() if clean_cell(x)]

    # Serial and name often appear in one line: ০০০১. নাম: ...
    for line in lines:
        m = re.search(r"^\s*([০-৯0-9]{2,7})\s*[.)]?\s*নাম\s*[:\-]?\s*(.*)$", line)
        if m:
            fields["ক্রমিক নং"] = clean_cell(m.group(1))
            fields["নাম"] = _before_any(m.group(2), ["ভোটার", "পিতা", "মাতা", "পেশা", "জন্ম", "ঠিকানা"])
            break

    # Serial fallback.
    if not fields["ক্রমিক নং"]:
        m = re.search(r"(?:ক্রমিক\s*নং|ক্রমিক)\s*[:\-]?\s*([০-৯0-9]{2,7})", text)
        if m:
            fields["ক্রমিক নং"] = clean_cell(m.group(1))
        else:
            m = re.search(r"\b([০-৯0-9]{3,7})\s*[.)]", text)
            if m:
                fields["ক্রমিক নং"] = clean_cell(m.group(1))

    for line in lines:
        compact = line.replace(" ", "")
        if not fields["নাম"] and "নাম" in line:
            val = _line_after_label(line, r"নাম")
            fields["নাম"] = _before_any(val, ["ভোটার", "পিতা", "মাতা", "পেশা", "জন্ম", "ঠিকানা"])

        if not fields["ভোটার নং"] and ("ভোটার" in line or "ভোটার" in line or "ভোটা" in line):
            val = _line_after_label(line, r"ভ[োে]টার\s*নং|ভ[োে]টার|ভোটা")
            fields["ভোটার নং"] = _before_any(val, ["নাম", "পিতা", "মাতা", "পেশা", "জন্ম", "ঠিকানা"])

        if not fields["পিতা"] and "পিতা" in line:
            val = _line_after_label(line, r"পিতা")
            fields["পিতা"] = _before_any(val, ["মাতা", "পেশা", "জন্ম", "ঠিকানা"])

        if not fields["মাতা"] and "মাতা" in line:
            val = _line_after_label(line, r"মাতা")
            fields["মাতা"] = _before_any(val, ["পিতা", "পেশা", "জন্ম", "ঠিকানা"])

        if "পেশা" in line:
            val = _line_after_label(line, r"পেশা")
            occ = _before_any(val, ["জন্ম", "তারিখ", "ঠিকানা"])
            if occ:
                fields["পেশা"] = occ
            m = re.search(r"জন্ম\s*তারিখ\s*[:\-]?\s*([০-৯0-9]{1,2}[/-][০-৯0-9]{1,2}[/-][۰-۹۰-۹০-৯0-9]{2,4}|[০-৯0-9]{4,8})", line)
            if m:
                fields["জন্ম তারিখ"] = clean_cell(m.group(1))

        if not fields["জন্ম তারিখ"] and ("জন্ম" in line or "তারিখ" in line):
            m = re.search(r"(?:জন্ম\s*তারিখ|তারিখ)\s*[:\-]?\s*([০-৯0-9]{1,2}[/-][০-۹0-9]{1,2}[/-][۰-۹০-۹0-9]{2,4}|[۰-۹0-9]{4,8})", line)
            if m:
                fields["জন্ম তারিখ"] = clean_cell(m.group(1))

        if not fields["ঠিকানা"] and "ঠিকানা" in line:
            val = _line_after_label(line, r"ঠিকানা")
            fields["ঠিকানা"] = clean_cell(val)

    # Full-text voter no fallback. Keep original digits as OCR produced.
    if not fields["ভোটার নং"]:
        m = re.search(r"(?:ভ[োে]টার\s*নং|ভ[োে]টার)\s*[:\-]?\s*([০-۹۰-۹0-9]{8,20})", text)
        if m:
            fields["ভোটার নং"] = clean_cell(m.group(1))

    # Full-text date fallback.
    if not fields["জন্ম তারিখ"]:
        m = re.search(r"([০-۹۰-۹0-9]{1,2}[/-][۰-۹0-9]{1,2}[/-][۰-۹0-9]{2,4})", text)
        if m:
            fields["জন্ম তারিখ"] = clean_cell(m.group(1))

    # Normalize only obvious trailing junk, not spelling/name content.
    for k in FIELD_NAMES:
        fields[k] = clean_cell(fields[k])

    required = ["ক্রমিক নং", "ভোটার নং", "নাম", "পিতা", "মাতা", "পেশা", "জন্ম তারিখ", "ঠিকানা"]
    missing = [k for k in required if not fields.get(k)]
    if missing:
        notes.append("Missing: " + ", ".join(missing))

    voter_no_en = bn_to_en_digits(fields.get("ভোটার নং", ""))
    if fields.get("ভোটার নং") and not re.fullmatch(r"\d{8,20}", voter_no_en):
        notes.append("Voter number pattern suspicious")

    date_en = bn_to_en_digits(fields.get("জন্ম তারিখ", ""))
    if fields.get("জন্ম তারিখ") and not re.fullmatch(r"\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|\d{4,8}", date_en):
        notes.append("Birth date pattern suspicious")

    if confidence and confidence < min_confidence:
        notes.append(f"Low OCR confidence: {confidence:.1f}")

    return ParseResult(fields=fields, needs_review=bool(notes), review_notes="; ".join(notes))




def extract_voter_area_number(raw_text: str) -> str:
    """Extract voter area number/code from a cover/header OCR text.

    Returns the number exactly as OCR/Bangla digits are detected, cleaned.
    """
    text = normalize_text(raw_text)
    text = text.replace("এলাকারনম্বর", "এলাকার নম্বর")
    text = text.replace("এলাকানম্বর", "এলাকার নম্বর")
    text = text.replace("এলাকারকোড", "এলাকার কোড")
    text = text.replace("এলাকাকোড", "এলাকার কোড")
    text = re.sub(r"\s+", " ", text)

    digit = r"[\u09E6-\u09EF0-9]"
    patterns = [
        rf"ভ[োে]টার\s*এলাকার\s*(?:নম্বর|নং|কোড)\s*[:\-]?\s*({digit}{{2,10}})",
        rf"ভ[োে]টার\s*এলাকা\s*(?:নম্বর|নং|কোড)\s*[:\-]?\s*({digit}{{2,10}})",
        rf"এলাকার\s*(?:নম্বর|নং|কোড)\s*[:\-]?\s*({digit}{{2,10}})",
        rf"এলাকা\s*(?:নম্বর|নং|কোড)\s*[:\-]?\s*({digit}{{2,10}})",
    ]
    for pattern in patterns:
        m = re.search(pattern, text)
        if m:
            return clean_cell(m.group(1))
    return ""
