from __future__ import annotations

from pathlib import Path


def render_pdf(pdf_path: Path, out_dir: Path, dpi: int = 400) -> list[Path]:
    """Render PDF pages to PNG files using PyMuPDF. Does not require poppler/pdftoppm."""
    try:
        import fitz  # PyMuPDF
    except Exception as exc:  # pragma: no cover
        raise RuntimeError("PyMuPDF missing. Run: pip install -r requirements.txt") from exc

    out_dir.mkdir(parents=True, exist_ok=True)
    doc = fitz.open(str(pdf_path))
    page_paths: list[Path] = []
    zoom = dpi / 72.0
    matrix = fitz.Matrix(zoom, zoom)
    for page_index in range(len(doc)):
        page = doc.load_page(page_index)
        pix = page.get_pixmap(matrix=matrix, alpha=False)
        out = out_dir / f"page_{page_index + 1:04d}.png"
        pix.save(str(out))
        page_paths.append(out)
    doc.close()
    return page_paths
