from __future__ import annotations

import json
import tempfile
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from .detect import crop_box, detect_voter_boxes, fallback_grid_boxes
from .ocr import check_tesseract, run_ocr
from .parse import FIELD_NAMES, extract_voter_area_number, parse_card_text
from .render import render_pdf
from .review import write_review_html
from .utils import (
    bn_to_en_digits,
    ensure_empty_dir,
    extract_zip,
    find_pdfs,
    init_db,
    insert_records,
    make_zip,
    safe_filename_base,
    safe_stem,
    write_csv,
)

SaveCropsMode = Literal["all", "flagged", "none"]
FilenameMode = Literal["voter_area", "original_pdf"]


@dataclass
class ProcessConfig:
    dpi: int = 400
    lang: str = "ben+eng"
    min_confidence: float = 70.0
    crop_padding: int = 8
    save_crops: SaveCropsMode = "all"
    fallback_rows: int = 6
    fallback_cols: int = 3
    write_raw_text: bool = True
    write_review_html: bool = True
    # Default behavior requested by the user: per-PDF output names use the PDF's
    # voter area number/code. If the area number cannot be detected, original
    # PDF filename is used as a safe fallback.
    filename_mode: FilenameMode = "voter_area"
    # English-normalized digits are safer for filenames and sorting. Example:
    # voter area no ২৬৩০ -> 2630.csv
    filename_digits: Literal["english", "original"] = "english"


MAIN_CSV_FIELDS = FIELD_NAMES
DEBUG_CSV_FIELDS = FIELD_NAMES + [
    "ভোটার এলাকার নম্বর",
    "source_pdf",
    "source_folder",
    "output_basename",
    "page_no",
    "card_no",
    "crop_image",
    "ocr_confidence",
    "needs_review",
    "review_notes",
    "raw_text",
]


def _record_has_content(record: dict) -> bool:
    text_fields = " ".join(str(record.get(k, "")) for k in FIELD_NAMES)
    return len(text_fields.strip()) >= 4 and bool(record.get("নাম") or record.get("ভোটার নং") or record.get("পিতা"))


def _unique_base(output_dir: Path, desired_base: str) -> str:
    """Avoid overwriting when two PDFs in the same folder share one area number."""
    base = safe_filename_base(desired_base, fallback="file")
    candidate = base
    idx = 2
    while any((output_dir / f"{candidate}{suffix}").exists() for suffix in [".csv", ".db", "_debug.csv", "_crops"]):
        candidate = f"{base}__{idx}"
        idx += 1
    return candidate


def _write_temp_crop(src_image: Path, dst_path: Path, *, top: float, bottom: float, left: float = 0.0, right: float = 1.0) -> bool:
    import cv2

    img = cv2.imread(str(src_image))
    if img is None:
        return False
    h, w = img.shape[:2]
    y1 = max(0, min(h - 1, int(h * top)))
    y2 = max(y1 + 1, min(h, int(h * bottom)))
    x1 = max(0, min(w - 1, int(w * left)))
    x2 = max(x1 + 1, min(w, int(w * right)))
    crop = img[y1:y2, x1:x2]
    dst_path.parent.mkdir(parents=True, exist_ok=True)
    return bool(cv2.imwrite(str(dst_path), crop))


def _detect_voter_area_number(page_images: list[Path], tmp_dir: Path, lang: str) -> tuple[str, str]:
    """OCR only small header/cover regions to find the voter area number.

    Works with both cover-page format ("ভোটার এলাকার নম্বর") and data-page
    header format ("ভোটার এলাকার কোড"). Returns (area_no, raw_header_text).
    """
    raw_parts: list[str] = []
    crop_specs: list[tuple[int, float, float, float, float, str]] = []
    if page_images:
        # Cover page metadata usually sits around the middle/lower half.
        crop_specs.append((0, 0.30, 0.82, 0.00, 0.62, "cover_left_meta"))
        crop_specs.append((0, 0.30, 0.82, 0.48, 1.00, "cover_right_meta"))
        crop_specs.append((0, 0.00, 1.00, 0.00, 1.00, "cover_full"))
    if len(page_images) > 1:
        # Data pages usually include area code/name in the top header.
        crop_specs.append((1, 0.00, 0.22, 0.00, 1.00, "data_header_p2"))
    if len(page_images) > 2:
        crop_specs.append((2, 0.00, 0.18, 0.00, 1.00, "data_header_p3"))

    for page_index, top, bottom, left, right, label in crop_specs:
        if page_index >= len(page_images):
            continue
        crop_path = tmp_dir / f"area_{label}.png"
        try:
            if not _write_temp_crop(page_images[page_index], crop_path, top=top, bottom=bottom, left=left, right=right):
                continue
            ocr = run_ocr(crop_path, lang=lang)
            text = ocr.text.strip()
            if text:
                raw_parts.append(f"--- {label} ---\n{text}")
            area_no = extract_voter_area_number(text)
            if area_no:
                return area_no, "\n".join(raw_parts)
        except Exception:
            # Header filename detection failure should not block main OCR.
            continue
    return "", "\n".join(raw_parts)


def _choose_output_base(pdf_path: Path, page_images: list[Path], tmp_dir: Path, config: ProcessConfig) -> tuple[str, str, str]:
    original_stem = safe_stem(pdf_path)
    if config.filename_mode != "voter_area":
        return original_stem, "", ""

    area_no, raw_header_text = _detect_voter_area_number(page_images, tmp_dir, config.lang)
    if not area_no:
        return original_stem, "", raw_header_text

    if config.filename_digits == "english":
        base_value = bn_to_en_digits(area_no)
    else:
        base_value = area_no
    return safe_filename_base(base_value, fallback=original_stem), area_no, raw_header_text


def process_pdf(pdf_path: Path, output_dir: Path, input_root: Path, config: ProcessConfig) -> list[dict]:
    original_stem = safe_stem(pdf_path)
    output_dir.mkdir(parents=True, exist_ok=True)
    tmp_dir = output_dir / f".{original_stem}_work"
    ensure_empty_dir(tmp_dir)
    page_dir = tmp_dir / "pages"

    records: list[dict] = []
    errors: list[str] = []
    area_no = ""
    raw_header_text = ""
    output_base = original_stem
    try:
        page_images = render_pdf(pdf_path, page_dir, dpi=config.dpi)
        desired_base, area_no, raw_header_text = _choose_output_base(pdf_path, page_images, tmp_dir, config)
        output_base = _unique_base(output_dir, desired_base)
        crop_dir = output_dir / f"{output_base}_crops"
        if config.save_crops != "none":
            crop_dir.mkdir(parents=True, exist_ok=True)

        card_global = 0
        for page_no, page_image in enumerate(page_images, start=1):
            boxes = detect_voter_boxes(page_image)
            used_fallback = False
            if len(boxes) < 3 and page_no > 1:
                # If contour detection fails on a data page, use a conservative grid.
                boxes = fallback_grid_boxes(page_image, rows=config.fallback_rows, cols=config.fallback_cols)
                used_fallback = True
            if not boxes:
                continue
            for page_card_no, box in enumerate(boxes, start=1):
                card_global += 1
                crop_rel = f"{output_base}_crops/page_{page_no:04d}_card_{page_card_no:03d}.png"
                crop_path = output_dir / crop_rel
                # OCR needs a crop even when user does not want crops saved permanently.
                tmp_crop_path = crop_path if config.save_crops != "none" else tmp_dir / f"crop_{page_no:04d}_{page_card_no:03d}.png"
                crop_box(page_image, box, tmp_crop_path, pad=config.crop_padding)
                try:
                    ocr = run_ocr(tmp_crop_path, lang=config.lang)
                    parsed = parse_card_text(ocr.text, min_confidence=config.min_confidence, confidence=ocr.confidence)
                    record = dict(parsed.fields)
                    record.update(
                        {
                            "ভোটার এলাকার নম্বর": area_no,
                            "source_pdf": pdf_path.name,
                            "source_folder": pdf_path.parent.relative_to(input_root).as_posix() if pdf_path.parent != input_root else "",
                            "output_basename": output_base,
                            "page_no": page_no,
                            "card_no": page_card_no,
                            "crop_image": crop_rel if config.save_crops != "none" else "",
                            "ocr_confidence": round(float(ocr.confidence), 2),
                            "needs_review": 1 if parsed.needs_review or used_fallback else 0,
                            "review_notes": parsed.review_notes + ("; Fallback grid crop" if used_fallback else ""),
                            "raw_text": ocr.text.strip(),
                        }
                    )
                    if _record_has_content(record):
                        # If user wants only flagged crops, delete non-flagged images after OCR.
                        if config.save_crops == "flagged" and not record["needs_review"]:
                            try:
                                tmp_crop_path.unlink()
                                record["crop_image"] = ""
                            except OSError:
                                pass
                        records.append(record)
                except Exception as exc:
                    errors.append(f"Page {page_no} card {page_card_no}: {exc}\n{traceback.format_exc()}")
    finally:
        try:
            import shutil

            shutil.rmtree(tmp_dir, ignore_errors=True)
        except Exception:
            pass

    # Per-PDF outputs named by voter area number/code when detected.
    write_csv(output_dir / f"{output_base}.csv", records, MAIN_CSV_FIELDS)
    write_csv(output_dir / f"{output_base}_debug.csv", records, DEBUG_CSV_FIELDS)
    review_records = [r for r in records if str(r.get("needs_review")) in {"1", "True", "true", "yes"}]
    write_csv(output_dir / f"{output_base}_needs_review.csv", review_records, DEBUG_CSV_FIELDS)

    conn = init_db(output_dir / f"{output_base}.db")
    insert_records(conn, records)
    conn.close()

    if config.write_raw_text:
        raw_txt = output_dir / f"{output_base}_raw_ocr.txt"
        with open(raw_txt, "w", encoding="utf-8") as f:
            f.write(f"--- header OCR for filename detection ---\n{raw_header_text}\n")
            for r in records:
                f.write(f"\n--- {r.get('source_pdf')} | page {r.get('page_no')} | card {r.get('card_no')} ---\n")
                f.write(str(r.get("raw_text", "")))
                f.write("\n")

    if config.write_review_html:
        title = f"Review - {output_base} ({pdf_path.name})"
        write_review_html(output_dir / f"{output_base}_review.html", records, title=title)

    report = {
        "pdf": pdf_path.name,
        "source_folder": pdf_path.parent.relative_to(input_root).as_posix() if pdf_path.parent != input_root else "",
        "voter_area_number": area_no,
        "output_basename": output_base,
        "records": len(records),
        "needs_review": len(review_records),
        "errors": errors,
    }
    (output_dir / f"{output_base}_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return records


def process_zip(input_zip: Path, output_zip: Path, config: ProcessConfig | None = None) -> dict:
    config = config or ProcessConfig()
    input_zip = Path(input_zip).resolve()
    output_zip = Path(output_zip).resolve()
    if not input_zip.exists():
        raise FileNotFoundError(f"Input ZIP not found: {input_zip}")

    ok, msg = check_tesseract(config.lang)
    if not ok:
        raise RuntimeError(msg)

    with tempfile.TemporaryDirectory(prefix="voter_ocr_") as tmp:
        tmp_path = Path(tmp)
        input_root = tmp_path / "input"
        output_root = tmp_path / "output"
        input_root.mkdir(parents=True, exist_ok=True)
        output_root.mkdir(parents=True, exist_ok=True)
        extract_zip(input_zip, input_root)
        pdfs = find_pdfs(input_root)
        if not pdfs:
            raise RuntimeError("No PDF files found inside ZIP.")

        all_records: list[dict] = []
        file_reports: list[dict] = []
        for pdf in pdfs:
            rel_parent = pdf.parent.relative_to(input_root)
            out_dir = output_root / rel_parent
            try:
                records = process_pdf(pdf, out_dir, input_root=input_root, config=config)
                all_records.extend(records)
                first = records[0] if records else {}
                file_reports.append(
                    {
                        "pdf": pdf.relative_to(input_root).as_posix(),
                        "voter_area_number": first.get("ভোটার এলাকার নম্বর", ""),
                        "output_basename": first.get("output_basename", ""),
                        "records": len(records),
                        "needs_review": sum(1 for r in records if str(r.get("needs_review")) in {"1", "True", "true", "yes"}),
                        "status": "ok",
                    }
                )
            except Exception as exc:
                error_dir = out_dir
                error_dir.mkdir(parents=True, exist_ok=True)
                (error_dir / f"{safe_stem(pdf)}_ERROR.txt").write_text(str(exc), encoding="utf-8")
                file_reports.append(
                    {
                        "pdf": pdf.relative_to(input_root).as_posix(),
                        "records": 0,
                        "needs_review": 0,
                        "status": "error",
                        "error": str(exc),
                    }
                )

        # Combined root outputs.
        write_csv(output_root / "all_records.csv", all_records, MAIN_CSV_FIELDS)
        write_csv(output_root / "all_records_debug.csv", all_records, DEBUG_CSV_FIELDS)
        review_records = [r for r in all_records if str(r.get("needs_review")) in {"1", "True", "true", "yes"}]
        write_csv(output_root / "all_needs_review.csv", review_records, DEBUG_CSV_FIELDS)
        conn = init_db(output_root / "all_records.db")
        insert_records(conn, all_records)
        conn.close()

        summary = {
            "input_zip": input_zip.name,
            "pdf_files": len(pdfs),
            "total_records": len(all_records),
            "needs_review": len(review_records),
            "tesseract": msg,
            "config": config.__dict__,
            "files": file_reports,
            "note": "PDF files are not copied into the output ZIP. Per-PDF output files are named by voter area number when detected.",
        }
        (output_root / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
        make_zip(output_root, output_zip)
        return summary
