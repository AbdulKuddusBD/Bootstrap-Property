from __future__ import annotations

import html
from pathlib import Path

from .parse import FIELD_NAMES


def write_review_html(path: Path, records: list[dict], title: str = "Voter OCR Review") -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    for i, r in enumerate(records, start=1):
        crop = html.escape(r.get("crop_image", ""))
        img_html = f'<img src="{crop}" loading="lazy" />' if crop else ""
        inputs = []
        for field in FIELD_NAMES:
            value = html.escape(str(r.get(field, "")), quote=True)
            inputs.append(
                f'<label>{html.escape(field)}<input name="r{i}_{html.escape(field)}" value="{value}"></label>'
            )
        needs = "bad" if str(r.get("needs_review", "0")) in {"1", "True", "true", "yes"} else "ok"
        raw = html.escape(str(r.get("raw_text", "")))
        notes = html.escape(str(r.get("review_notes", "")))
        rows.append(
            f"""
            <section class="card {needs}">
              <div class="meta"><b>#{i}</b> | Area: {html.escape(str(r.get('ভোটার এলাকার নম্বর','')))} | PDF: {html.escape(str(r.get('source_pdf','')))} | Page: {html.escape(str(r.get('page_no','')))} | Card: {html.escape(str(r.get('card_no','')))} | Conf: {html.escape(str(r.get('ocr_confidence','')))}</div>
              <div class="notes">{notes}</div>
              <div class="wrap"><div class="image">{img_html}</div><div class="fields">{''.join(inputs)}</div></div>
              <details><summary>Raw OCR text</summary><pre>{raw}</pre></details>
            </section>
            """
        )

    content = f"""<!doctype html>
<html lang="bn">
<head>
<meta charset="utf-8">
<title>{html.escape(title)}</title>
<style>
body{{font-family:system-ui,Arial,Noto Sans Bengali,sans-serif;background:#f6f7f9;margin:0;padding:24px;color:#111}}
h1{{margin-top:0}}
.help{{background:#fff;border:1px solid #ddd;padding:12px;border-radius:10px;margin-bottom:16px}}
.card{{background:#fff;border:1px solid #ddd;border-radius:12px;margin:14px 0;padding:14px;box-shadow:0 1px 4px rgba(0,0,0,.04)}}
.card.bad{{border-left:7px solid #d93025}}
.card.ok{{border-left:7px solid #188038}}
.meta{{font-size:14px;margin-bottom:8px;color:#333}}
.notes{{font-size:14px;margin-bottom:10px;color:#a00000}}
.wrap{{display:grid;grid-template-columns:minmax(280px,40%) 1fr;gap:16px;align-items:start}}
.image img{{max-width:100%;border:1px solid #bbb;border-radius:6px;background:white}}
.fields{{display:grid;grid-template-columns:1fr 1fr;gap:10px}}
label{{font-size:13px;color:#333;display:flex;flex-direction:column;gap:4px}}
input{{font-size:16px;padding:8px;border:1px solid #bbb;border-radius:7px}}
pre{{white-space:pre-wrap;background:#f1f3f4;padding:10px;border-radius:8px}}
@media(max-width:800px){{.wrap{{grid-template-columns:1fr}}.fields{{grid-template-columns:1fr}}}}
</style>
</head>
<body>
<h1>{html.escape(title)}</h1>
<div class="help">লাল বর্ডার মানে এই রেকর্ডটি অবশ্যই দেখে ঠিক করা দরকার। এই HTML ফাইলটি review করার জন্য। Final correction করার সবচেয়ে সহজ উপায়: একই ফোল্ডারের CSV ফাইল Excel/LibreOffice দিয়ে খুলে crop image দেখে field ঠিক করে save করুন, তারপর tools/rebuild_db_from_csv.py চালিয়ে DB আবার বানান।</div>
{''.join(rows)}
</body>
</html>"""
    path.write_text(content, encoding="utf-8")
