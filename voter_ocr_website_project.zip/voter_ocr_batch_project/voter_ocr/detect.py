from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Literal


@dataclass(frozen=True)
class Box:
    x: int
    y: int
    w: int
    h: int

    @property
    def area(self) -> int:
        return self.w * self.h

    def padded(self, pad: int, width: int, height: int) -> "Box":
        x1 = max(0, self.x - pad)
        y1 = max(0, self.y - pad)
        x2 = min(width, self.x + self.w + pad)
        y2 = min(height, self.y + self.h + pad)
        return Box(x1, y1, max(1, x2 - x1), max(1, y2 - y1))


def _iou(a: Box, b: Box) -> float:
    x1 = max(a.x, b.x)
    y1 = max(a.y, b.y)
    x2 = min(a.x + a.w, b.x + b.w)
    y2 = min(a.y + a.h, b.y + b.h)
    inter = max(0, x2 - x1) * max(0, y2 - y1)
    if inter == 0:
        return 0.0
    return inter / float(a.area + b.area - inter)


def sort_boxes_row_major(boxes: list[Box]) -> list[Box]:
    if not boxes:
        return []
    boxes = sorted(boxes, key=lambda b: (b.y, b.x))
    heights = sorted([b.h for b in boxes])
    median_h = heights[len(heights) // 2]
    row_tol = max(12, int(median_h * 0.45))
    rows: list[list[Box]] = []
    for box in boxes:
        placed = False
        for row in rows:
            row_y = sum(b.y for b in row) / len(row)
            if abs(box.y - row_y) <= row_tol:
                row.append(box)
                placed = True
                break
        if not placed:
            rows.append([box])
    rows = sorted(rows, key=lambda row: sum(b.y for b in row) / len(row))
    out: list[Box] = []
    for row in rows:
        out.extend(sorted(row, key=lambda b: b.x))
    return out


def detect_voter_boxes(page_image_path: Path) -> list[Box]:
    """Detect rectangular voter cards from a rendered page image.

    Works best for Bangladesh Election Commission voter list pages where each voter
    appears inside a bordered rectangle arranged in columns.
    """
    try:
        import cv2
        import numpy as np
    except Exception as exc:  # pragma: no cover
        raise RuntimeError("OpenCV missing. Run: pip install -r requirements.txt") from exc

    image = cv2.imread(str(page_image_path))
    if image is None:
        raise RuntimeError(f"Could not read image: {page_image_path}")
    height, width = image.shape[:2]
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Invert black lines/text on white paper.
    blur = cv2.GaussianBlur(gray, (3, 3), 0)
    th = cv2.adaptiveThreshold(
        blur, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY_INV, 31, 15
    )

    # Extract long horizontal and vertical border lines.
    hor_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (max(20, width // 28), 1))
    ver_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, max(20, height // 35)))
    horizontal = cv2.morphologyEx(th, cv2.MORPH_OPEN, hor_kernel, iterations=1)
    vertical = cv2.morphologyEx(th, cv2.MORPH_OPEN, ver_kernel, iterations=1)
    lines = cv2.add(horizontal, vertical)
    close_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
    lines = cv2.morphologyEx(lines, cv2.MORPH_CLOSE, close_kernel, iterations=2)

    contours, _ = cv2.findContours(lines, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    candidates: list[Box] = []
    for cnt in contours:
        x, y, w, h = cv2.boundingRect(cnt)
        area = w * h
        if area <= 0:
            continue
        # Voter cards are medium-width rectangles. Header table is too wide; title lines too thin.
        if not (0.20 * width <= w <= 0.38 * width):
            continue
        if not (0.06 * height <= h <= 0.20 * height):
            continue
        if y < 0.08 * height:
            # Skip top header/title/table remnants.
            continue
        # Avoid tiny broken detections.
        if area < 0.015 * width * height:
            continue
        candidates.append(Box(int(x), int(y), int(w), int(h)))

    # Remove duplicates / overlapping nested boxes.
    candidates = sorted(candidates, key=lambda b: b.area, reverse=True)
    filtered: list[Box] = []
    for box in candidates:
        if all(_iou(box, old) < 0.45 for old in filtered):
            filtered.append(box)

    return sort_boxes_row_major(filtered)


def fallback_grid_boxes(page_image_path: Path, rows: int = 5, cols: int = 3) -> list[Box]:
    """Fallback crop grid for pages where line detection fails.

    This is intentionally conservative and may include blank crops on the last page.
    Blank crops are filtered later by OCR/parse quality.
    """
    try:
        import cv2
    except Exception as exc:  # pragma: no cover
        raise RuntimeError("OpenCV missing. Run: pip install -r requirements.txt") from exc

    image = cv2.imread(str(page_image_path))
    if image is None:
        raise RuntimeError(f"Could not read image: {page_image_path}")
    height, width = image.shape[:2]

    left = int(width * 0.085)
    right = int(width * 0.915)
    top = int(height * 0.16)
    bottom = int(height * 0.88)
    gap_x = int(width * 0.012)
    gap_y = int(height * 0.010)
    cell_w = (right - left - gap_x * (cols - 1)) // cols
    cell_h = (bottom - top - gap_y * (rows - 1)) // rows

    boxes: list[Box] = []
    for r in range(rows):
        for c in range(cols):
            x = left + c * (cell_w + gap_x)
            y = top + r * (cell_h + gap_y)
            boxes.append(Box(x, y, cell_w, cell_h))
    return boxes


def crop_box(page_image_path: Path, box: Box, out_path: Path, pad: int = 8) -> Path:
    import cv2

    image = cv2.imread(str(page_image_path))
    if image is None:
        raise RuntimeError(f"Could not read image: {page_image_path}")
    height, width = image.shape[:2]
    box = box.padded(pad, width, height)
    crop = image[box.y : box.y + box.h, box.x : box.x + box.w]
    out_path.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(out_path), crop)
    return out_path
