from __future__ import annotations

import os
import re
import tempfile
from dataclasses import dataclass
from pathlib import Path


@dataclass
class OCRResult:
    text: str
    confidence: float
    labels_found: int
    variant_name: str


LABELS = ["নাম", "ভোটার", "পিতা", "মাতা", "পেশা", "জন্ম", "ঠিকানা"]


def check_tesseract(lang: str = "ben+eng") -> tuple[bool, str]:
    try:
        import pytesseract
        version = pytesseract.get_tesseract_version()
        langs = set(pytesseract.get_languages(config=""))
        missing = []
        for item in lang.split("+"):
            if item and item not in langs:
                missing.append(item)
        if missing:
            return False, f"Tesseract found ({version}), but missing language data: {', '.join(missing)}"
        return True, f"Tesseract ready ({version}), languages OK: {lang}"
    except Exception as exc:
        return False, f"Tesseract/PyTesseract not ready: {exc}"


def _preprocess_variants(image_path: Path) -> list[tuple[str, object]]:
    import cv2

    image = cv2.imread(str(image_path))
    if image is None:
        raise RuntimeError(f"Could not read image: {image_path}")
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Fast/balanced mode: only two useful variants. Older project used many variants
    # and two separate Tesseract calls per variant, which can take many hours.
    up = cv2.resize(gray, None, fx=2.0, fy=2.0, interpolation=cv2.INTER_CUBIC)
    variants: list[tuple[str, object]] = [("gray_2x", up)]

    ad = cv2.adaptiveThreshold(up, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 35, 11)
    variants.append(("adaptive_2x", ad))
    return variants


def _text_from_data(data: dict) -> str:
    words = data.get("text", []) or []
    block_nums = data.get("block_num", []) or []
    par_nums = data.get("par_num", []) or []
    line_nums = data.get("line_num", []) or []
    rows: list[tuple[tuple[int, int, int], str]] = []
    for i, word in enumerate(words):
        word = str(word).strip()
        if not word:
            continue
        key = (
            int(block_nums[i]) if i < len(block_nums) else 0,
            int(par_nums[i]) if i < len(par_nums) else 0,
            int(line_nums[i]) if i < len(line_nums) else 0,
        )
        rows.append((key, word))
    lines: list[str] = []
    current_key = None
    current_words: list[str] = []
    for key, word in rows:
        if current_key is None:
            current_key = key
        if key != current_key:
            lines.append(" ".join(current_words))
            current_words = []
            current_key = key
        current_words.append(word)
    if current_words:
        lines.append(" ".join(current_words))
    return "\n".join(lines)


def _ocr_image_array(image, lang: str, psm: int, timeout: int = 45) -> OCRResult:
    import cv2
    import pytesseract

    config = f"--oem 1 --psm {psm} -c preserve_interword_spaces=1"
    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
        temp_path = tmp.name
    try:
        cv2.imwrite(temp_path, image)
        # One Tesseract call only. image_to_data gives both words and confidence.
        data = pytesseract.image_to_data(
            temp_path,
            lang=lang,
            config=config,
            output_type=pytesseract.Output.DICT,
            timeout=timeout,
        )
        text = _text_from_data(data)
        confs = []
        for c in data.get("conf", []):
            try:
                val = float(c)
                if val >= 0:
                    confs.append(val)
            except Exception:
                pass
        confidence = sum(confs) / len(confs) if confs else 0.0
        labels_found = sum(1 for label in LABELS if label in text)
        return OCRResult(text=text, confidence=confidence, labels_found=labels_found, variant_name="")
    finally:
        try:
            os.unlink(temp_path)
        except OSError:
            pass


def run_ocr(image_path: Path, lang: str = "ben+eng") -> OCRResult:
    """Run Bengali OCR in faster balanced mode and choose the best variant."""
    try:
        import pytesseract  # noqa: F401
    except Exception as exc:  # pragma: no cover
        raise RuntimeError("pytesseract missing. Run: pip install -r requirements.txt") from exc

    best: OCRResult | None = None
    best_score = -1.0
    for name, img in _preprocess_variants(image_path):
        for psm in (6,):
            try:
                result = _ocr_image_array(img, lang=lang, psm=psm, timeout=45)
            except RuntimeError as exc:
                result = OCRResult(text=f"OCR_TIMEOUT_OR_ERROR: {exc}", confidence=0.0, labels_found=0, variant_name=f"{name}_psm{psm}")
            result.variant_name = f"{name}_psm{psm}"
            text_len = len(re.sub(r"\s+", "", result.text))
            score = result.labels_found * 1000 + result.confidence * 10 + min(text_len, 250)
            if best is None or score > best_score:
                best = result
                best_score = score
    return best or OCRResult("", 0.0, 0, "none")
