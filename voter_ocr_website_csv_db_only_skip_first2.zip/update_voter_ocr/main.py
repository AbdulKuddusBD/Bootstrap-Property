from __future__ import annotations

import argparse
import json
from pathlib import Path

from voter_ocr.processor import ProcessConfig, process_zip


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Batch OCR Bangladesh voter-list PDFs from a ZIP and export CSV + SQLite DB."
    )
    parser.add_argument("--input", "-i", required=True, help="Input ZIP path containing PDF files in any folders")
    parser.add_argument("--output", "-o", required=True, help="Output ZIP path")
    parser.add_argument("--dpi", type=int, default=300, help="PDF render DPI. 250-350 recommended. Default: 300")
    parser.add_argument("--data-start-page", type=int, default=3, help="Start extracting voter records from this PDF page number. Default: 3, so page 1 and page 2 are skipped.")
    parser.add_argument("--lang", default="ben+eng", help="Tesseract language, default: ben+eng")
    parser.add_argument("--min-confidence", type=float, default=70.0, help="Records below this OCR confidence are flagged")
    parser.add_argument(
        "--save-crops",
        choices=["all", "flagged", "none"],
        default="none",
        help="Internal/debug only. Final output ZIP includes only CSV and DB files.",
    )
    parser.add_argument("--fallback-rows", type=int, default=6, help="Rows used if automatic box detection fails")
    parser.add_argument("--fallback-cols", type=int, default=3, help="Columns used if automatic box detection fails")
    parser.add_argument(
        "--filename-mode",
        choices=["voter_area", "original_pdf"],
        default="voter_area",
        help="Per-PDF output filenames: voter_area uses the detected voter area number; original_pdf uses the PDF filename.",
    )
    parser.add_argument(
        "--filename-digits",
        choices=["english", "original"],
        default="english",
        help="When filename-mode is voter_area, use English-normalized digits like 2630, or original digits like ২৬৩০.",
    )
    return parser


def main() -> None:
    args = build_parser().parse_args()
    config = ProcessConfig(
        dpi=args.dpi,
        data_start_page=max(1, args.data_start_page),
        lang=args.lang,
        min_confidence=args.min_confidence,
        save_crops=args.save_crops,
        fallback_rows=args.fallback_rows,
        fallback_cols=args.fallback_cols,
        filename_mode=args.filename_mode,
        filename_digits=args.filename_digits,
    )
    summary = process_zip(Path(args.input), Path(args.output), config=config)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print(f"\nDONE: {Path(args.output).resolve()}")


if __name__ == "__main__":
    main()
