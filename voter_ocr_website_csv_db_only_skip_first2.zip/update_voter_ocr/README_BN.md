# Update: প্রথম ২ পৃষ্ঠা বাদ

এই version-এ প্রতিটি PDF/বইয়ের **প্রথম পৃষ্ঠা এবং দ্বিতীয় পৃষ্ঠা record extraction থেকে বাদ দেওয়া হবে**। Voter data নেওয়া শুরু হবে **তৃতীয় পৃষ্ঠা থেকে**।

Filename detect করার জন্য cover/header OCR করা হতে পারে, কিন্তু CSV/DB record export হবে data_start_page অনুযায়ী। Default:

```text
data_start_page = 3
```

Website form-এ `Data Start Page` field আছে। দরকার হলে 3 থেকে পরিবর্তন করা যাবে।

# Voter OCR Website - CSV/DB Only Fixed Version

এই version-এ output ZIP-এর ভিতরে শুধু প্রতি PDF-এর `.csv` এবং `.db` থাকবে।

Fix:
- Empty CSV/DB issue fixed.
- Voter card border/grid detection improved.
- Regex parse error fixed.
- Header table text আর fake record হিসেবে export হবে না.
- Filename: ভোটার এলাকার নম্বর + পুরুষ/মহিলা।

চালানোর path: `/root/update_voter_ocr`


# Voter OCR Website - CSV/DB Only Version

এই version আপনার চাহিদা অনুযায়ী output ZIP-এর ভিতরে শুধুমাত্র CSV এবং DB file রাখবে।

## Output format

প্রতিটি PDF থেকে একই folder structure অনুযায়ী ২টি file তৈরি হবে:

```text
2630_পুরুষ.csv
2630_পুরুষ.db
```

অথবা মহিলা হলে:

```text
2630_মহিলা.csv
2630_মহিলা.db
```

CSV column হবে শুধু:

```text
ক্রমিক নং, ভোটার নং, নাম, পিতা, মাতা, পেশা, জন্ম তারিখ, ঠিকানা
```

DB file-এ `voters` table থাকবে। Columns:

```text
serial_no, voter_no, name, father, mother, occupation, birth_date, address
```

Output ZIP-এ থাকবে না:

```text
PDF
crop image
review html
debug csv
raw ocr txt
summary json
report json
```

## Run on VPS

Project folder যদি হয় `/root/update_voter_ocr`, তাহলে:

```bash
cd /root/update_voter_ocr
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
pip install gunicorn
```

Tesseract install:

```bash
apt update
apt install -y tesseract-ocr tesseract-ocr-ben libgl1 libglib2.0-0
```

Check:

```bash
which tesseract
tesseract --list-langs
```

`ben` এবং `eng` থাকা দরকার।

## systemd service

```bash
cat > /etc/systemd/system/voter-ocr.service <<'SERVICE'
[Unit]
Description=Voter OCR Website CSV DB Only
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/root/update_voter_ocr
Environment="PATH=/root/update_voter_ocr/venv/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
ExecStart=/root/update_voter_ocr/venv/bin/gunicorn --workers 1 --threads 8 --timeout 0 --bind 0.0.0.0:8000 web_app:app
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
SERVICE

systemctl daemon-reload
systemctl enable voter-ocr
systemctl restart voter-ocr
systemctl status voter-ocr
```

Open:

```text
http://103.174.51.115:8000
```

Live log:

```bash
journalctl -u voter-ocr -f -o cat
```

## Speed note

এই version crop/debug/review file তৈরি করে না এবং page OCR timeout কম রাখা হয়েছে, তাই আগের version থেকে দ্রুত এবং output ZIP ছোট হবে। OCR scan quality-এর উপর নির্ভর করে, তাই বড় কাজের আগে ছোট ZIP দিয়ে test করুন।
