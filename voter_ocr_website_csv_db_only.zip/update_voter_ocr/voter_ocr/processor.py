from __future__ import annotations

import json
import tempfile
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from .detect import crop_box, detect_voter_boxes, fallback_grid_boxes
from .ocr import check_tesseract, run_ocr, run_page_ocr_words, words_inside_box_to_text
from .parse import FIELD_NAMES, extract_voter_area_number, parse_card_text
from .render import render_pdf
from .utils import (
    bn_to_en_digits,
    ensure_empty_dir,
    extract_zip,
    find_pdfs,
    init_db,
    insert_records,
    make_zip,
    safe_filename_base,
    safe_stem,
    write_csv,
)

SaveCropsMode = Literal["all", "flagged", "none"]
FilenameMode = Literal["voter_area", "original_pdf"]


@dataclass
class ProcessConfig:
    dpi: int = 300
    lang: str = "ben+eng"
    min_confidence: float = 70.0
    crop_padding: int = 8
    save_crops: SaveCropsMode = "none"
    fallback_rows: int = 6
    fallback_cols: int = 3
    write_raw_text: bool = False
    write_review_html: bool = False
    # ultra_fast_page = OCR once per page, then split text into voter boxes.
    # accurate_card = old mode, OCR every voter card separately (slower).
    ocr_mode: Literal["ultra_fast_page", "accurate_card"] = "ultra_fast_page"
    fallback_to_card_ocr: bool = False
    # Default behavior requested by the user: per-PDF output names use the PDF's
    # voter area number/code. If the area number cannot be detected, original
    # PDF filename is used as a safe fallback.
    filename_mode: FilenameMode = "voter_area"
    # English-normalized digits are safer for filenames and sorting. Example:
    # voter area no ২৬৩০ -> 2630.csv
    filename_digits: Literal["english", "original"] = "english"


MAIN_CSV_FIELDS = FIELD_NAMES


def _record_has_content(record: dict) -> bool:
    text_fields = " ".join(str(record.get(k, "")) for k in FIELD_NAMES)
    return len(text_fields.strip()) >= 4 and bool(record.get("নাম") or record.get("ভোটার নং") or record.get("পিতা"))


def _unique_base(output_dir: Path, desired_base: str) -> str:
    """Avoid overwriting when two PDFs in the same folder share one area number."""
    base = safe_filename_base(desired_base, fallback="file")
    candidate = base
    idx = 2
    while any((output_dir / f"{candidate}{suffix}").exists() for suffix in [".csv", ".db"]):
        candidate = f"{base}__{idx}"
        idx += 1
    return candidate


def _write_temp_crop(src_image: Path, dst_path: Path, *, top: float, bottom: float, left: float = 0.0, right: float = 1.0) -> bool:
    import cv2

    img = cv2.imread(str(src_image))
    if img is None:
        return False
    h, w = img.shape[:2]
    y1 = max(0, min(h - 1, int(h * top)))
    y2 = max(y1 + 1, min(h, int(h * bottom)))
    x1 = max(0, min(w - 1, int(w * left)))
    x2 = max(x1 + 1, min(w, int(w * right)))
    crop = img[y1:y2, x1:x2]
    dst_path.parent.mkdir(parents=True, exist_ok=True)
    return bool(cv2.imwrite(str(dst_path), crop))


def _detect_gender_from_text(text: str) -> str:
    if not text:
        return ""
    compact = text.replace(" ", "")
    if "মহিলা" in compact or "নারী" in compact:
        return "মহিলা"
    if "পুরুষ" in compact or "পূরুষ" in compact:
        return "পুরুষ"
    return ""


def _detect_gender_from_filename(pdf_path: Path) -> str:
    name = pdf_path.name.lower()
    if "female" in name or "woman" in name or "women" in name or "mohila" in name or "mahila" in name:
        return "মহিলা"
    # Check male after female so female does not accidentally match a loose male rule.
    if "male" in name or "purush" in name or "purush" in name:
        return "পুরুষ"
    return ""


def _detect_voter_area_number(page_images: list[Path], tmp_dir: Path, lang: str) -> tuple[str, str, str]:
    """OCR small header/cover regions to find voter area number and gender.

    Returns (area_no, gender, raw_header_text). Gender is Bangla: পুরুষ/মহিলা.
    """
    raw_parts: list[str] = []
    crop_specs: list[tuple[int, float, float, float, float, str]] = []
    if page_images:
        # Cover page metadata usually sits around the middle/lower half.
        crop_specs.append((0, 0.30, 0.82, 0.00, 0.62, "cover_left_meta"))
        crop_specs.append((0, 0.30, 0.82, 0.48, 1.00, "cover_right_meta"))
        crop_specs.append((0, 0.00, 1.00, 0.00, 1.00, "cover_full"))
    if len(page_images) > 1:
        # Data pages usually include area code/name in the top header.
        crop_specs.append((1, 0.00, 0.22, 0.00, 1.00, "data_header_p2"))
    if len(page_images) > 2:
        crop_specs.append((2, 0.00, 0.18, 0.00, 1.00, "data_header_p3"))

    for page_index, top, bottom, left, right, label in crop_specs:
        if page_index >= len(page_images):
            continue
        crop_path = tmp_dir / f"area_{label}.png"
        try:
            if not _write_temp_crop(page_images[page_index], crop_path, top=top, bottom=bottom, left=left, right=right):
                continue
            ocr = run_ocr(crop_path, lang=lang)
            text = ocr.text.strip()
            if text:
                raw_parts.append(f"--- {label} ---\n{text}")
            gender = _detect_gender_from_text(text)
            area_no = extract_voter_area_number(text)
            if area_no:
                return area_no, gender, "\n".join(raw_parts)
        except Exception:
            # Header filename detection failure should not block main OCR.
            continue
    gender = _detect_gender_from_text("\n".join(raw_parts))
    return "", gender, "\n".join(raw_parts)


def _choose_output_base(pdf_path: Path, page_images: list[Path], tmp_dir: Path, config: ProcessConfig) -> tuple[str, str, str, str]:
    original_stem = safe_stem(pdf_path)
    fallback_gender = _detect_gender_from_filename(pdf_path)
    if config.filename_mode != "voter_area":
        base = original_stem + (f"_{fallback_gender}" if fallback_gender else "")
        return safe_filename_base(base, fallback=original_stem), "", fallback_gender, ""

    area_no, gender, raw_header_text = _detect_voter_area_number(page_images, tmp_dir, config.lang)
    gender = gender or fallback_gender
    if not area_no:
        base = original_stem + (f"_{gender}" if gender else "")
        return safe_filename_base(base, fallback=original_stem), "", gender, raw_header_text

    if config.filename_digits == "english":
        base_value = bn_to_en_digits(area_no)
    else:
        base_value = area_no
    if gender:
        base_value = f"{base_value}_{gender}"
    return safe_filename_base(base_value, fallback=original_stem), area_no, gender, raw_header_text


def process_pdf(pdf_path: Path, output_dir: Path, input_root: Path, config: ProcessConfig) -> list[dict]:
    print(f"[VOTER-OCR] START PDF: {pdf_path}", flush=True)
    original_stem = safe_stem(pdf_path)
    output_dir.mkdir(parents=True, exist_ok=True)
    tmp_dir = output_dir / f".{original_stem}_work"
    ensure_empty_dir(tmp_dir)
    page_dir = tmp_dir / "pages"

    records: list[dict] = []
    errors: list[str] = []
    area_no = ""
    gender = ""
    raw_header_text = ""
    output_base = original_stem
    try:
        page_images = render_pdf(pdf_path, page_dir, dpi=config.dpi)
        print(f"[VOTER-OCR] Rendered {len(page_images)} pages: {pdf_path.name}", flush=True)
        desired_base, area_no, gender, raw_header_text = _choose_output_base(pdf_path, page_images, tmp_dir, config)
        output_base = _unique_base(output_dir, desired_base)

        card_global = 0
        for page_no, page_image in enumerate(page_images, start=1):
            print(f"[VOTER-OCR] Detecting boxes: {pdf_path.name} page {page_no}/{len(page_images)}", flush=True)
            boxes = detect_voter_boxes(page_image)
            used_fallback = False
            if len(boxes) < 3 and page_no > 1:
                # If contour detection fails on a data page, use a conservative grid.
                boxes = fallback_grid_boxes(page_image, rows=config.fallback_rows, cols=config.fallback_cols)
                used_fallback = True
            if not boxes:
                continue

            page_words = []
            page_ocr_confidence = 0.0
            if config.ocr_mode == "ultra_fast_page":
                try:
                    print(f"[VOTER-OCR] Ultra-fast page OCR: {pdf_path.name} page {page_no}/{len(page_images)} boxes={len(boxes)}", flush=True)
                    page_words, page_ocr_confidence, _page_raw_text = run_page_ocr_words(page_image, lang=config.lang)
                    print(f"[VOTER-OCR] Page OCR words={len(page_words)} confidence={page_ocr_confidence:.1f}: {pdf_path.name} page {page_no}/{len(page_images)}", flush=True)
                except Exception as exc:
                    errors.append(f"Page {page_no} page-level OCR failed, falling back to card OCR: {exc}\n{traceback.format_exc()}")
                    page_words = []

            print(f"[VOTER-OCR] Parsing cards: {pdf_path.name} page {page_no}/{len(page_images)} boxes={len(boxes)}", flush=True)
            for page_card_no, box in enumerate(boxes, start=1):
                card_global += 1
                crop_rel = f"{output_base}_crops/page_{page_no:04d}_card_{page_card_no:03d}.png"
                crop_path = output_dir / crop_rel
                tmp_crop_path = tmp_dir / f"crop_{page_no:04d}_{page_card_no:03d}.png"
                try:
                    ocr_text = ""
                    ocr_confidence = 0.0
                    ocr_source = "page"
                    if config.ocr_mode == "ultra_fast_page" and page_words:
                        ocr_text, ocr_confidence = words_inside_box_to_text(page_words, (box.x, box.y, box.w, box.h), pad=config.crop_padding + 2)
                    else:
                        crop_box(page_image, box, tmp_crop_path, pad=config.crop_padding)
                        ocr = run_ocr(tmp_crop_path, lang=config.lang)
                        ocr_text, ocr_confidence = ocr.text, ocr.confidence
                        ocr_source = "card"

                    parsed = parse_card_text(ocr_text, min_confidence=config.min_confidence, confidence=ocr_confidence)
                    record = dict(parsed.fields)

                    # If page-level OCR did not produce usable content for this card,
                    # fall back to the slower per-card OCR for this one card only.
                    if config.ocr_mode == "ultra_fast_page" and config.fallback_to_card_ocr and not _record_has_content(record):
                        crop_box(page_image, box, tmp_crop_path, pad=config.crop_padding)
                        ocr = run_ocr(tmp_crop_path, lang=config.lang)
                        ocr_text, ocr_confidence = ocr.text, ocr.confidence
                        ocr_source = "card_fallback"
                        parsed = parse_card_text(ocr_text, min_confidence=config.min_confidence, confidence=ocr_confidence)
                        record = dict(parsed.fields)

                    needs_review = parsed.needs_review or used_fallback or ocr_source != "page"
                    save_this_crop = config.save_crops == "all" or (config.save_crops == "flagged" and needs_review)
                    if save_this_crop:
                        crop_box(page_image, box, crop_path, pad=config.crop_padding)
                    record.update(
                        {
                            "ভোটার এলাকার নম্বর": area_no,
                            "source_pdf": pdf_path.name,
                            "source_folder": pdf_path.parent.relative_to(input_root).as_posix() if pdf_path.parent != input_root else "",
                            "output_basename": output_base,
                            "page_no": page_no,
                            "card_no": page_card_no,
                            "crop_image": crop_rel if save_this_crop else "",
                            "ocr_confidence": round(float(ocr_confidence), 2),
                            "needs_review": 1 if needs_review else 0,
                            "review_notes": parsed.review_notes + ("; Fallback grid crop" if used_fallback else "") + (f"; OCR source: {ocr_source}" if ocr_source != "page" else ""),
                            "raw_text": ocr_text.strip(),
                        }
                    )
                    if _record_has_content(record):
                        records.append(record)
                    if page_card_no % 5 == 0:
                        print(f"[VOTER-OCR] Progress: {pdf_path.name} page {page_no}/{len(page_images)} card {page_card_no}/{len(boxes)}", flush=True)
                except Exception as exc:
                    errors.append(f"Page {page_no} card {page_card_no}: {exc}\n{traceback.format_exc()}")
    finally:
        try:
            import shutil

            shutil.rmtree(tmp_dir, ignore_errors=True)
        except Exception:
            pass

    print(f"[VOTER-OCR] FINISH PDF: {pdf_path.name}, records={len(records)}", flush=True)

    # Final output per PDF: only CSV and SQLite DB. No crops/debug/review/raw/report files.
    write_csv(output_dir / f"{output_base}.csv", records, MAIN_CSV_FIELDS)

    conn = init_db(output_dir / f"{output_base}.db")
    insert_records(conn, records)
    conn.close()

    return records


def process_zip(input_zip: Path, output_zip: Path, config: ProcessConfig | None = None) -> dict:
    config = config or ProcessConfig()
    input_zip = Path(input_zip).resolve()
    output_zip = Path(output_zip).resolve()
    if not input_zip.exists():
        raise FileNotFoundError(f"Input ZIP not found: {input_zip}")

    ok, msg = check_tesseract(config.lang)
    if not ok:
        raise RuntimeError(msg)

    with tempfile.TemporaryDirectory(prefix="voter_ocr_") as tmp:
        tmp_path = Path(tmp)
        input_root = tmp_path / "input"
        output_root = tmp_path / "output"
        input_root.mkdir(parents=True, exist_ok=True)
        output_root.mkdir(parents=True, exist_ok=True)
        extract_zip(input_zip, input_root)
        pdfs = find_pdfs(input_root)
        print(f"[VOTER-OCR] ZIP extracted. Total PDFs: {len(pdfs)}", flush=True)
        if not pdfs:
            raise RuntimeError("No PDF files found inside ZIP.")

        all_records: list[dict] = []
        file_reports: list[dict] = []
        for pdf_index, pdf in enumerate(pdfs, start=1):
            print(f"[VOTER-OCR] Processing PDF {pdf_index}/{len(pdfs)}: {pdf.relative_to(input_root)}", flush=True)
            rel_parent = pdf.parent.relative_to(input_root)
            out_dir = output_root / rel_parent
            try:
                records = process_pdf(pdf, out_dir, input_root=input_root, config=config)
                all_records.extend(records)
                first = records[0] if records else {}
                file_reports.append(
                    {
                        "pdf": pdf.relative_to(input_root).as_posix(),
                        "voter_area_number": first.get("ভোটার এলাকার নম্বর", ""),
                        "output_basename": first.get("output_basename", ""),
                        "records": len(records),
                        "needs_review": sum(1 for r in records if str(r.get("needs_review")) in {"1", "True", "true", "yes"}),
                        "status": "ok",
                    }
                )
            except Exception as exc:
                file_reports.append(
                    {
                        "pdf": pdf.relative_to(input_root).as_posix(),
                        "records": 0,
                        "needs_review": 0,
                        "status": "error",
                        "error": str(exc),
                    }
                )

        summary = {
            "input_zip": input_zip.name,
            "total_pdfs": len(pdfs),
            "total_records": len(all_records),
            "output_files": "Only per-PDF .csv and .db files are included in the output ZIP.",
            "files": file_reports,
        }
        print(f"[VOTER-OCR] Making output ZIP: {output_zip}", flush=True)
        make_zip(output_root, output_zip)
        print(f"[VOTER-OCR] DONE. Records={len(all_records)} Output=CSV+DB only", flush=True)
        return summary
